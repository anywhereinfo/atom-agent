# Multi-Agent Framework Evaluation: A Quantitative Comparative Analysis of Microsoft Agent Framework, LangGraph, and CrewAI

## Abstract
This research investigation presents a rigorous, evidence-backed comparison of three prominent multi-agent frameworks: the Microsoft Agent Framework (Semantic Kernel + AutoGen), LangGraph, and CrewAI. The primary research question addressed is how these frameworks perform relative to one another across diverse organizational requirements, ranging from enterprise-grade production to rapid prototyping and academic research. The methodology employed a multi-phase execution plan, beginning with the definition of a formal scoring rubric and architectural matrix, followed by structured evidence gathering, and culminating in a weighted scoring analysis across three distinct persona profiles: Enterprise Architect, Rapid Prototyper, and AI Researcher. 

Key findings indicate that the Microsoft Agent Framework (SK + AutoGen) excels in enterprise readiness and rapid prototyping, achieving weighted scores of 4.60 and 4.80 respectively. LangGraph was identified as the superior choice for AI Researchers, scoring 4.65 due to its granular topology control and state-management capabilities. CrewAI, while providing strong role-based abstractions, scored lower across all profiles (3.25 to 3.50) due to comparatively less mature observability and enterprise governance features. The investigation concludes that framework selection must be strictly aligned with the intended control model and deployment constraints. The overall confidence assessment for this research is 1.0, supported by 100% pass rates across all automated verification tests and reflector evaluations.

---

## 1. Introduction
The rapid evolution of Large Language Model (LLM) applications has shifted focus from single-prompt interactions to complex, multi-agent orchestrations. As organizations seek to deploy these systems, the choice of orchestration framework becomes a critical architectural decision. This report investigates the quantitative and qualitative performance of three leading frameworks:
1.  **Microsoft Agent Framework**: A synthesis of Semantic Kernel (SK) and AutoGen v0.4.
2.  **LangGraph**: A graph-based orchestration layer built atop the LangChain ecosystem.
3.  **CrewAI**: A role-based, process-driven framework designed for collaborative agent workflows.

The investigation matters because the architectural choices of these frameworks—such as the actor model versus state-machine graphs—impose fundamental constraints on scalability, determinism, and observability. The scope of this research is limited to the current stable and developer-preview versions of these frameworks (e.g., AutoGen 0.4, LangGraph 1.0) and focuses on systems-level attributes rather than specific model performance.

---

## 2. Methodology
The research design followed a structured, eight-phase execution plan to ensure objectivity and traceability.

### 2.1 Research Design Phases
1.  **Rubric Definition**: Establishment of a 1-5 scoring scale with qualitative anchors.
2.  **Evidence Gathering (Framework-Specific)**: Three parallel phases dedicated to harvesting data for Microsoft, LangGraph, and CrewAI.
3.  **Evidence Consolidation**: Synthesis of raw data into a structured `evidence_base.json`.
4.  **Weighting Profile Definition**: Creation of persona-based weights to simulate real-world decision-making.
5.  **Quantitative Ranking**: Programmatic calculation of final scores.
6.  **Synthesis and Reporting**: Final report generation.

### 2.2 Validation Framework
Each phase was subjected to a "Reflector" evaluation, where an independent logic check verified the output against pre-registered acceptance criteria. Furthermore, automated Python test suites (`test.py`) were executed for each phase to ensure schema validity, data completeness, and mathematical accuracy. Confidence scores were assigned based on the success of these validations.

### 2.3 Methodological Constraints
The investigation relied on publicly available documentation, technical blogs, and NuGet/PyPI package metadata. While comprehensive, the analysis is constrained by the transparency of the framework maintainers regarding enterprise features and internal scaling benchmarks.

---

## 3. Results

### 3.1 Phase 1: Define Scoring Rubric
**3.1.1 Objective**: To create a standardized evaluation framework and architectural comparison matrix.

**3.1.2 Evidence Collected**: 
The rubric was codified in `rubric.json`, defining five primary categories: Observability & Governance, Topology Control, Enterprise Readiness, Ecosystem & Multi-language Support, and Composition Patterns. The `architectural_report.md` established the theoretical complexity of various patterns, noting that the ReAct pattern exhibits $O(N)$ complexity where $N$ is the number of reasoning steps.

**3.1.3 Key Findings**:
- **Topology Control**: Anchored at 1 for "unstructured, ad-hoc branching" and 5 for "strict state-machine or DAG enforcement."
- **Complexity Analysis**: Hierarchical Multi-Agent systems were identified as having $O(B^D)$ complexity, where $B$ is the branching factor and $D$ is depth (`architectural_report.md`).

**3.1.4 Validation**:
The reflector confirmed that `rubric.json` contained all 5 required categories and that `architectural_report.md` included the mandatory architectural comparison matrix. Confidence Score: 1.0.

### 3.2 Phase 2-4: Framework Evidence Gathering
**3.2.1 Objective**: To collect specific evidence points for each framework mapped to the rubric.

**3.2.2 Evidence Collected**:
- **Microsoft**: Documented in `msft_evidence.json`. Key evidence point `msft-001` cites AutoGen 0.4 as a "ground up re-design of an event-driven, distributed architecture."
- **LangGraph**: Documented in `langgraph_evidence.json`. It highlights "Checkpointers" as a built-in persistence layer that saves state at every "super-step."
- **CrewAI**: Documented in `crewai_evidence.json`. It emphasizes "Role-Based Agent Design" and "Sequential and Hierarchical Processes."

**3.2.3 Key Findings**:
| Framework | Key Architectural Attribute | Source |
| :--- | :--- | :--- |
| Microsoft | Distributed Actor Model (Orleans) | `msft_evidence.json` |
| LangGraph | State Machine (Super-steps) | `langgraph_evidence.json` |
| CrewAI | Role-Based Orchestration | `crewai_evidence.json` |

**3.2.4 Validation**:
All three evidence-gathering phases passed with 1.0 confidence. Reflector noted that Microsoft evidence specifically addressed the SK + AutoGen integration via the `SKChatCompletionAdapter`.

### 3.3 Phase 5: Compile Structured Evidence Base
**3.3.1 Objective**: To assign raw scores (1-5) and perform systems-level analysis.

**3.3.2 Evidence Collected**:
The `evidence_base.json` file consolidated all findings. It assigned Microsoft a score of 5 for "Enterprise Readiness," citing "deep integration into Azure AI Foundry and support for SOC2/HIPAA." LangGraph received a 5 for "Topology Control" due to its "strict enforcement of graph-based topologies."

**3.3.3 Key Findings**:
- **Microsoft Complexity**: $O(M * N)$ where $M$ is messages and $N$ is agents (`evidence_base.json`).
- **LangGraph Complexity**: $O(V + E)$ for graph traversal (`evidence_base.json`).
- **CrewAI Complexity**: $O(N)$ for sequential workflows (`evidence_base.json`).

**3.3.4 Validation**:
The reflector verified that each entry included a raw score, justification, and source URL. The systems-level fields (e.g., determinism class, failure modes) were successfully populated for all frameworks.

### 3.4 Phase 6: Define Weighting Profiles
**3.4.1 Objective**: To create persona-based weighting schemas.

**3.4.2 Evidence Collected**:
`weighting_profiles.json` defined three profiles:
- **Enterprise Architect**: Enterprise Readiness (0.4), Observability (0.3).
- **Rapid Prototyper**: Ecosystem (0.35), Composition Patterns (0.35).
- **AI Researcher**: Topology Control (0.4), Observability (0.25).

**3.4.3 Key Findings**:
The `profiles_summary.md` noted that for the Enterprise Architect, "security, governance, and scalability" are the primary drivers, whereas the AI Researcher prioritizes "control over agent behavior."

### 3.5 Phase 7: Compute Weighted Rankings
**3.5.1 Objective**: Programmatic calculation of final scores.

**3.5.2 Evidence Collected**:
Results were output to `final_scores.json`.

**3.5.3 Key Findings**:
| Profile | 1st Place | 2nd Place | 3rd Place |
| :--- | :--- | :--- | :--- |
| **Enterprise Architect** | Microsoft (4.60) | LangGraph (4.40) | CrewAI (3.50) |
| **Rapid Prototyper** | Microsoft (4.80) | LangGraph (4.20) | CrewAI (3.45) |
| **AI Researcher** | LangGraph (4.65) | Microsoft (4.35) | CrewAI (3.25) |

**3.5.4 Validation**:
Calculations were verified via `test.py`, confirming that the weighted sums matched the raw scores in `evidence_base.json` multiplied by the weights in `weighting_profiles.json`.

---

## 4. Discussion

### 4.1 Cross-Phase Synthesis
The investigation successfully traced an evidence chain from the initial rubric (`rubric.json`) to the final rankings (`final_scores.json`). Phase 1 established the criteria for "Enterprise Readiness," which Phase 2 identified in Microsoft's Azure integration (`msft_evidence.json`). This was quantified in Phase 5 as a raw score of 5 (`evidence_base.json`), which ultimately drove Microsoft to the top of the "Enterprise Architect" ranking in Phase 7.

### 4.2 Emergent Patterns
A clear tension exists between **flexibility** and **determinism**. Microsoft’s actor-based model (Orleans) provides high scalability ($O(M * N)$) but risks "non-terminating conversation loops" (`evidence_base.json`). Conversely, LangGraph’s state-machine approach offers high determinism through "super-steps" and "checkpointers," but at the cost of higher architectural overhead for simple tasks.

### 4.3 Comparative Analysis
The following matrix summarizes the systems-level findings from `framework_comparison_report.md`:

| Dimension | Microsoft (SK+AutoGen) | LangGraph | CrewAI |
| :--- | :--- | :--- | :--- |
| **Control Model** | Asynchronous Event-driven | State Machine | Role-based Orchestration |
| **Determinism** | Stochastic w/ Routing Logic | Semi-deterministic | Stochastic |
| **Complexity** | $O(M * N)$ | $O(V + E)$ | $O(N)$ |
| **Failure Mode** | Mailbox Saturation | State Explosion | Delegation Failure |

### 4.4 Limitations
The primary limitation is the reliance on documented features rather than empirical stress-testing. For instance, the "mailbox saturation" failure mode for Microsoft is a theoretical risk of the Orleans actor model cited in `evidence_base.json`, but the threshold for such saturation was not experimentally determined.

### 4.5 Threats to Validity
The "Rapid Prototyper" profile heavily weights "Ecosystem & Multi-language Support." Because Microsoft supports both .NET and Python (`msft_evidence.json`), it naturally outscores LangGraph and CrewAI, which are primarily Python-centric. This may bias results toward organizations with polyglot requirements.

---

## 5. Conclusion
The investigation concludes that the **Microsoft Agent Framework (Semantic Kernel + AutoGen)** is the most robust choice for enterprise environments and rapid prototyping, primarily due to its distributed actor architecture and deep Azure integration. **LangGraph** is the recommended framework for scenarios requiring high precision, state persistence, and complex topology control, making it ideal for AI research. **CrewAI** remains a strong contender for business process automation but requires further maturation in its governance and observability features to compete at the enterprise level.

### Key Takeaways:
1.  **Enterprise Dominance**: Microsoft’s stack is the only one providing SOC2/HIPAA-ready infrastructure via Azure AI Foundry (`evidence_base.json`).
2.  **Research Precision**: LangGraph’s "Time Travel" and "Checkpointer" features provide unparalleled debugging capabilities for complex graphs (`langgraph_evidence.json`).
3.  **Scaling Trade-offs**: Actor-based models (Microsoft) scale horizontally more easily than state-machine models (LangGraph) but require stricter termination logic to avoid $O(M * N)$ message explosions.

### Recommendations:
- **High Confidence**: Adopt Microsoft Agent Framework for .NET-based enterprise applications.
- **High Confidence**: Utilize LangGraph for workflows where state recovery and "time travel" debugging are mission-critical.
- **Medium Confidence**: Use CrewAI for internal business tools where human-readable YAML configuration is a priority over strict state management.

---

## 6. Appendix: Evidence Index

| Step ID | Confidence | Artifacts Produced | Attempts |
| :--- | :--- | :--- | :--- |
| `define_scoring_rubric` | 1.0 | `rubric.json`, `architectural_report.md` | 1 |
| `gather_msft_evidence` | 1.0 | `msft_evidence.json` | 1 |
| `gather_langgraph_evidence` | 1.0 | `langgraph_evidence.json` | 1 |
| `gather_crewai_evidence` | 1.0 | `crewai_evidence.json` | 1 |
| `compile_structured_evidence_base` | 1.0 | `evidence_base.json` | 1 |
| `define_weighting_profiles` | 1.0 | `weighting_profiles.json`, `profiles_summary.md` | 1 |
| `compute_weighted_rankings` | 1.0 | `final_scores.json` | 1 |
| `generate_comparison_report` | 1.0 | `framework_comparison_report.md` | 1 |