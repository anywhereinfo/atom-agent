import json
import os

def generate_report():
    # Load data
    rubric = json.load(open('steps/define_scoring_rubric/committed/artifacts/rubric.json'))
    profiles = json.load(open('steps/define_weighting_profiles/committed/artifacts/weighting_profiles.json'))
    evidence = json.load(open('steps/compile_structured_evidence_base/committed/artifacts/evidence_base.json'))
    scores = json.load(open('steps/compute_weighted_rankings/committed/artifacts/final_scores.json'))

    report = []
    report.append("# Multi-Agent Framework Comparison Report\n")
    report.append("## Executive Summary")
    report.append("This report provides a comprehensive comparison of three leading multi-agent frameworks: Microsoft Agent Framework (Semantic Kernel + AutoGen), LangGraph, and CrewAI. The evaluation is based on a structured rubric and three distinct weighting profiles to cater to different organizational needs.\n")

    report.append("## Methodology")
    report.append("### Scoring Rubric")
    report.append("The frameworks were evaluated across several categories, including Observability & Governance, Topology Control, Enterprise Readiness, Ecosystem Support, Composition Patterns, and Systems Analysis. Each category was scored from 1 to 5 based on specific criteria defined in the rubric.\n")
    
    report.append("### Weighting Profiles")
    report.append("To reflect different priorities, we used three weighting profiles:")
    for profile_name, weights in profiles.items():
        report.append(f"- **{profile_name}**: Focuses on {', '.join([f'{k} ({v})' for k, v in weights.items() if v > 0.15])}.")
    report.append("\n")

    report.append("## Architectural Comparison Matrix")
    headers = ["Feature", "Microsoft (SK+AutoGen)", "LangGraph", "CrewAI"]
    rows = [
        ("Planning Topology", "planning_topology"),
        ("Control Model", "control_model"),
        ("Computational Complexity", "computational_complexity"),
        ("Determinism Class", "determinism_class"),
        ("Observability/Governance", "observability_governance"),
        ("Enterprise Suitability", "enterprise_suitability"),
        ("Composition Patterns", "composition_patterns")
    ]
    
    matrix_table = "| " + " | ".join(headers) + " |\n"
    matrix_table += "| " + " | ".join(["---"] * len(headers)) + " |\n"
    for label, key in rows:
        row_data = [label]
        for fw in ["Microsoft Agent Framework (SK + AutoGen)", "LangGraph", "CrewAI"]:
            val = evidence[fw].get('Systems Analysis', {}).get(key, "N/A")
            row_data.append(val)
        matrix_table += "| " + " | ".join(row_data) + " |\n"
    report.append(matrix_table)
    report.append("\n")

    report.append("## Results by Profile")
    for profile_name, fw_scores_list in scores.items():
        report.append(f"### Profile: {profile_name}")
        report.append("| Framework | Weighted Score |")
        report.append("| --- | --- |")
        # fw_scores_list is already sorted in compute_weighted_rankings usually, but let's be safe
        sorted_scores = sorted(fw_scores_list, key=lambda x: x['score'], reverse=True)
        for item in sorted_scores:
            report.append(f"| {item['framework']} | {item['score']:.2f} |")
        report.append("\n")

    report.append("## Detailed Framework Analysis")
    for fw, data in evidence.items():
        report.append(f"### {fw}")
        sys_analysis = data.get('Systems Analysis', {})
        
        report.append("#### Systems Analysis")
        report.append(f"- **Computational Complexity:** {sys_analysis.get('computational_complexity', 'N/A')}")
        report.append(f"- **Determinism:** {sys_analysis.get('determinism_class', 'N/A')}")
        report.append(f"- **Failure Modes:** {sys_analysis.get('failure_modes', 'N/A')}")
        
        report.append("#### Cost & Latency Implications")
        if "Microsoft" in fw:
            report.append("Cost scales with message volume and agent count. Latency is primarily driven by conversation depth and LLM response times. Asynchronous execution helps mitigate blocking but increases complexity in state tracking.")
        elif "LangGraph" in fw:
            report.append("Cost is proportional to the number of nodes visited and state persistence operations. Latency is deterministic regarding graph traversal but stochastic regarding node execution.")
        elif "CrewAI" in fw:
            report.append("Cost is driven by the number of tasks and the overhead of the manager agent's orchestration. Sequential execution has linear latency, while hierarchical execution depends on tree depth.")

        report.append("#### Failure Scenario")
        report.append(f"> {sys_analysis.get('failure_scenario', 'N/A')}\n")
        
        report.append("#### Production Use Case")
        report.append(f"> {sys_analysis.get('production_use_case', 'N/A')}\n")

    report.append("## Enterprise Deployment Guidance")
    report.append("### Cost Predictability")
    report.append("- **LangGraph** offers the highest predictability due to its explicit state machine transitions.")
    report.append("- **Microsoft/AutoGen** can be less predictable due to autonomous agent interactions.")
    report.append("- **CrewAI** predictability depends on the clarity of task definitions and manager agent efficiency.")
    
    report.append("### Reliability & Security")
    report.append("- **Microsoft/SK** provides robust enterprise-grade security and integration with Azure.")
    report.append("- **LangGraph** provides excellent reliability through its persistence and 'time-travel' debugging capabilities.")
    report.append("- **CrewAI** is best suited for internal process automation where absolute reliability is less critical than ease of use.")

    report.append("## Evidence Appendix")
    for fw, data in evidence.items():
        report.append(f"### {fw} Sources")
        sources = set()
        for cat, content in data.items():
            if isinstance(content, dict) and 'sources' in content:
                sources.update(content['sources'])
        for src in sources:
            report.append(f"- [{src}]({src})")
    
    # Write report to artifacts
    output_path = 'steps/generate_comparison_report/attempts/a01/artifacts/framework_comparison_report.md'
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        f.write("\n".join(report))

if __name__ == "__main__":
    generate_report()
