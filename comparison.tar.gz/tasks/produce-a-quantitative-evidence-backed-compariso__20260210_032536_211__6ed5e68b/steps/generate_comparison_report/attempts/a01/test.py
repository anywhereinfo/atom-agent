import os
import pytest

REPORT_PATH = 'steps/generate_comparison_report/attempts/a01/artifacts/framework_comparison_report.md'

def test_report_exists():
    assert os.path.exists(REPORT_PATH)

def test_report_sections():
    with open(REPORT_PATH, 'r') as f:
        content = f.read()
    
    assert "## Methodology" in content
    assert "## Results by Profile" in content
    assert "## Evidence Appendix" in content
    assert "## Architectural Comparison Matrix" in content
    assert "## Enterprise Deployment Guidance" in content

def test_systems_level_fields():
    with open(REPORT_PATH, 'r') as f:
        content = f.read()
    
    # Check for systems-level fields in the matrix or detailed analysis
    fields = [
        "Planning Topology",
        "Control Model",
        "Computational Complexity",
        "Failure Modes",
        "Determinism",
        "Observability/Governance",
        "Enterprise Suitability",
        "Composition Patterns"
    ]
    for field in fields:
        assert field in content

def test_failure_and_use_cases():
    with open(REPORT_PATH, 'r') as f:
        content = f.read()
    
    assert "Failure Scenario" in content
    assert "Production Use Case" in content
    
    # Check for specific frameworks
    assert "Microsoft Agent Framework" in content
    assert "LangGraph" in content
    assert "CrewAI" in content

def test_complexity_analysis():
    with open(REPORT_PATH, 'r') as f:
        content = f.read()
    
    # Check for formal notation O(...)
    assert "O(" in content

def test_enterprise_guidance():
    with open(REPORT_PATH, 'r') as f:
        content = f.read()
    
    assert "Cost Predictability" in content
    assert "Reliability" in content
    assert "Security" in content
