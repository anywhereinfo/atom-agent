import json
import os
import pytest

def test_evidence_base_exists():
    path = "steps/compile_structured_evidence_base/attempts/a01/artifacts/evidence_base.json"
    assert os.path.exists(path), "evidence_base.json does not exist"

def test_evidence_base_structure():
    path = "steps/compile_structured_evidence_base/attempts/a01/artifacts/evidence_base.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    frameworks = ["Microsoft Agent Framework (SK + AutoGen)", "LangGraph", "CrewAI"]
    for fw in frameworks:
        assert fw in data, f"Framework {fw} missing from evidence base"
        
        # Check categories
        categories = ["Observability & Governance", "Topology Control", "Enterprise Readiness", 
                      "Ecosystem & Multi-language Support", "Composition Patterns", "Systems Analysis"]
        for cat in categories:
            assert cat in data[fw], f"Category {cat} missing for framework {fw}"
            assert "score" in data[fw][cat], f"Score missing for {fw} -> {cat}"
            assert isinstance(data[fw][cat]["score"], int), f"Score for {fw} -> {cat} must be an integer"
            assert 1 <= data[fw][cat]["score"] <= 5, f"Score for {fw} -> {cat} must be between 1 and 5"
            assert "justification" in data[fw][cat], f"Justification missing for {fw} -> {cat}"
            assert isinstance(data[fw][cat]["justification"], str), f"Justification for {fw} -> {cat} must be a string"
            assert "sources" in data[fw][cat], f"Sources missing for {fw} -> {cat}"
            assert isinstance(data[fw][cat]["sources"], list), f"Sources for {fw} -> {cat} must be a list"
            assert len(data[fw][cat]["sources"]) >= 1, f"At least one source required for {fw} -> {cat}"

def test_systems_level_fields():
    path = "steps/compile_structured_evidence_base/attempts/a01/artifacts/evidence_base.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    systems_fields = [
        "planning_topology", "control_model", "computational_complexity", 
        "failure_modes", "determinism_class", "observability_governance", 
        "enterprise_suitability", "composition_patterns", "failure_scenario", "production_use_case"
    ]
    
    for fw in data:
        # We put these in the 'Systems Analysis' category
        sys_cat = data[fw]["Systems Analysis"]
        for field in systems_fields:
            assert field in sys_cat, f"Systems-level field '{field}' missing for framework {fw}"
            assert sys_cat[field], f"Systems-level field '{field}' for framework {fw} is empty"

def test_analytical_depth():
    path = "steps/compile_structured_evidence_base/attempts/a01/artifacts/evidence_base.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    for fw, categories in data.items():
        sys_cat = categories["Systems Analysis"]
        
        # Check for formal complexity notation
        assert "O(" in sys_cat["computational_complexity"], f"Computational complexity for {fw} should include formal notation (e.g., O(N))"
        
        # Check for failure scenario and production use case
        assert len(sys_cat["failure_scenario"]) > 20, f"Failure scenario for {fw} is too short"
        assert len(sys_cat["production_use_case"]) > 20, f"Production use case for {fw} is too short"

if __name__ == "__main__":
    pytest.main([__file__])
