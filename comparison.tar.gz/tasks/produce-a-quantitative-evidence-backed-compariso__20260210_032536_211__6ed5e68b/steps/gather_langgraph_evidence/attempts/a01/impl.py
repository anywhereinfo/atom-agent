import json
import os

def main():
    evidence = [
        {
            "category": "Persistence & Checkpointers",
            "feature": "Checkpointers",
            "evidence": "LangGraph has a built-in persistence layer, implemented through checkpointers. When you compile a graph with a checkpointer, the checkpointer saves a 'checkpoint' of the graph state at every super-step.",
            "source": "https://docs.langchain.com/oss/python/langgraph/persistence",
            "tags": ["persistence", "checkpointer", "super-step"]
        },
        {
            "category": "State Management",
            "feature": "Threads",
            "evidence": "The checkpointer uses 'thread_id' as the primary key for storing and retrieving checkpoints. Without it, the checkpointer cannot save state or resume execution after an interrupt.",
            "source": "https://docs.langchain.com/oss/python/langgraph/persistence",
            "tags": ["threads", "state-isolation", "thread_id"]
        },
        {
            "category": "State Management",
            "feature": "Reducers",
            "evidence": "State is the single source of truth for your LangGraph workflow design... control how updates merge (reducers in LangGraph), persist it with checkpointers.",
            "source": "https://medium.com/@bharatraj1918/langgraph-state-management-part-1-how-langgraph-manages-state-for-multi-agent-workflows-da64d352c43b",
            "tags": ["state", "reducers", "schema"]
        },
        {
            "category": "Control Flow & Topology",
            "feature": "Time Travel / State Editing",
            "evidence": "Time travel: You can go back to any previous checkpoint and see the state... In addition to re-playing the graph from specific checkpoints, we can also edit the graph state. We do this using 'update_state'.",
            "source": "https://medium.com/@vinodkrane/mastering-persistence-in-langgraph-checkpoints-threads-and-beyond-21e412aaed60",
            "tags": ["time-travel", "update_state", "debugging"]
        },
        {
            "category": "Control Flow & Topology",
            "feature": "Graph-based Execution (Super-steps)",
            "evidence": "Every time your graph executes a step (called a 'super-step'), LangGraph automatically creates a checkpoint — a complete snapshot of your graph's state at that moment.",
            "source": "https://medium.com/@vinodkrane/mastering-persistence-in-langgraph-checkpoints-threads-and-beyond-21e412aaed60",
            "tags": ["topology", "super-step", "graph"]
        }
    ]

    output_dir = "steps/gather_langgraph_evidence/attempts/a01/artifacts"
    os.makedirs(output_dir, exist_ok=True)
    
    output_path = os.path.join(output_dir, "langgraph_evidence.json")
    with open(output_path, "w") as f:
        json.dump(evidence, f, indent=2)
    
    print(f"Evidence written to {output_path}")

if __name__ == "__main__":
    main()
