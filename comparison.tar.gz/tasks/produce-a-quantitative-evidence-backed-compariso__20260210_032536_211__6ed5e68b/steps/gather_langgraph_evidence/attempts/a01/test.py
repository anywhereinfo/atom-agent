import json
import os

def test_evidence_file_exists():
    path = "steps/gather_langgraph_evidence/attempts/a01/artifacts/langgraph_evidence.json"
    assert os.path.exists(path), "langgraph_evidence.json does not exist"

def test_evidence_count():
    path = "steps/gather_langgraph_evidence/attempts/a01/artifacts/langgraph_evidence.json"
    with open(path, "r") as f:
        data = json.load(f)
    assert len(data) >= 5, f"Expected at least 5 evidence points, found {len(data)}"

def test_evidence_structure():
    path = "steps/gather_langgraph_evidence/attempts/a01/artifacts/langgraph_evidence.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    required_keys = ["category", "feature", "evidence", "source"]
    for entry in data:
        for key in required_keys:
            assert key in entry, f"Missing key '{key}' in evidence entry"
            assert entry[key], f"Empty value for key '{key}'"

def test_langgraph_1_0_features():
    path = "steps/gather_langgraph_evidence/attempts/a01/artifacts/langgraph_evidence.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    content = json.dumps(data).lower()
    assert "checkpointer" in content, "Evidence should cover 'checkpointers'"
    assert "thread" in content, "Evidence should cover 'threads'"

def test_rubric_categories():
    path = "steps/gather_langgraph_evidence/attempts/a01/artifacts/langgraph_evidence.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    categories = {entry["category"] for entry in data}
    # Expecting coverage of state management, persistence, and topology
    assert any("Persistence" in cat for cat in categories), "Missing Persistence category"
    assert any("State" in cat for cat in categories), "Missing State Management category"
    assert any("Topology" in cat or "Flow" in cat for cat in categories), "Missing Topology/Flow category"
