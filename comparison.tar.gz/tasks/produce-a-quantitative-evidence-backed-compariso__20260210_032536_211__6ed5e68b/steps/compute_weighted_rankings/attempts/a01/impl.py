import json
import os

def compute_rankings(evidence_path, profiles_path, output_path):
    with open(evidence_path, 'r') as f:
        evidence = json.load(f)
    
    with open(profiles_path, 'r') as f:
        profiles = json.load(f)
    
    results = {}
    
    for profile_name, weights in profiles.items():
        profile_results = []
        for framework_name, categories in evidence.items():
            weighted_score = 0.0
            for category, weight in weights.items():
                if category in categories:
                    score = categories[category].get('score', 0)
                    weighted_score += weight * score
                else:
                    # If a category is missing in evidence, treat score as 0
                    pass
            
            profile_results.append({
                "framework": framework_name,
                "score": round(weighted_score, 2)
            })
        
        # Sort by score descending, then by name ascending for stability
        profile_results.sort(key=lambda x: (-x['score'], x['framework']))
        results[profile_name] = profile_results
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)

if __name__ == "__main__":
    # Paths relative to task root
    evidence_base_path = "steps/compile_structured_evidence_base/committed/artifacts/evidence_base.json"
    weighting_profiles_path = "steps/define_weighting_profiles/committed/artifacts/weighting_profiles.json"
    output_file = "steps/compute_weighted_rankings/attempts/a01/artifacts/final_scores.json"
    
    compute_rankings(evidence_base_path, weighting_profiles_path, output_file)
