import json
import os
import pytest

def test_final_scores_exists():
    path = "steps/compute_weighted_rankings/attempts/a01/artifacts/final_scores.json"
    assert os.path.exists(path)

def test_profiles_present():
    path = "steps/compute_weighted_rankings/attempts/a01/artifacts/final_scores.json"
    with open(path, 'r') as f:
        scores = json.load(f)
    
    expected_profiles = ["AI Researcher", "Enterprise Architect", "Rapid Prototyper"]
    for profile in expected_profiles:
        assert profile in scores

def test_calculation_accuracy():
    # Load inputs
    with open("steps/compile_structured_evidence_base/committed/artifacts/evidence_base.json", 'r') as f:
        evidence = json.load(f)
    with open("steps/define_weighting_profiles/committed/artifacts/weighting_profiles.json", 'r') as f:
        profiles = json.load(f)
    
    # Load output
    with open("steps/compute_weighted_rankings/attempts/a01/artifacts/final_scores.json", 'r') as f:
        final_scores = json.load(f)
    
    for profile_name, weights in profiles.items():
        for framework_entry in final_scores[profile_name]:
            framework_name = framework_entry['framework']
            expected_score = 0.0
            for category, weight in weights.items():
                score = evidence[framework_name][category]['score']
                expected_score += weight * score
            
            assert framework_entry['score'] == round(expected_score, 2)

def test_ranking_order():
    path = "steps/compute_weighted_rankings/attempts/a01/artifacts/final_scores.json"
    with open(path, 'r') as f:
        scores = json.load(f)
    
    for profile, results in scores.items():
        current_scores = [r['score'] for r in results]
        assert current_scores == sorted(current_scores, reverse=True)

def test_systems_level_dimensions_traceability():
    # Ensure that the frameworks ranked actually have the required analytical depth in the source
    with open("steps/compile_structured_evidence_base/committed/artifacts/evidence_base.json", 'r') as f:
        evidence = json.load(f)
    
    required_fields = [
        "planning_topology",
        "control_model",
        "computational_complexity",
        "failure_modes",
        "determinism_class",
        "observability_governance",
        "enterprise_suitability",
        "composition_patterns",
        "failure_scenario",
        "production_use_case"
    ]
    
    for framework, data in evidence.items():
        assert "Systems Analysis" in data
        analysis = data["Systems Analysis"]
        for field in required_fields:
            assert field in analysis
            assert analysis[field] is not None
            assert len(str(analysis[field])) > 0
