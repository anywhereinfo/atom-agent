import json
import os

def generate_rubric(artifacts_path):
    rubric = {
        "categories": [
            {
                "name": "Observability & Governance",
                "description": "The ability to monitor, trace, and control agentic workflows in real-time and post-hoc.",
                "anchors": {
                    "1": "Black-box execution with no logging or tracing; no mechanism for human intervention.",
                    "5": "Full OpenTelemetry tracing, real-time state visualization, granular RBAC, and mandatory Human-in-the-loop (HITL) for critical actions."
                }
            },
            {
                "name": "Topology Control",
                "description": "The precision and flexibility in defining the flow of control between agents and tools.",
                "anchors": {
                    "1": "Unstructured, ad-hoc branching with no formal state management; prone to infinite loops.",
                    "5": "Strict state-machine or DAG enforcement with deterministic transition logic and cycle detection."
                }
            },
            {
                "name": "Enterprise Readiness",
                "description": "Support for production requirements like security, scalability, and multi-tenancy.",
                "anchors": {
                    "1": "Single-user, local-only execution; no security sandboxing for tool use.",
                    "5": "Multi-tenant architecture, secure sandboxed tool execution (e.g., gVisor/Wasm), and SOC2-compliant audit trails."
                }
            },
            {
                "name": "Ecosystem & Multi-language Support",
                "description": "Integration with existing infrastructure and support for diverse development environments.",
                "anchors": {
                    "1": "Proprietary DSL only; locked into a single programming language or framework.",
                    "5": "Standardized protocol support (e.g., MCP), polyglot SDKs, and a rich library of pre-verified tool integrations."
                }
            },
            {
                "name": "Composition Patterns",
                "description": "The ease with which agentic units can be nested, reused, and scaled.",
                "anchors": {
                    "1": "Monolithic design; agents cannot be easily decomposed or reused in different contexts.",
                    "5": "Recursive, modular composition where agents can act as tools for other agents with standardized interfaces."
                }
            }
        ]
    }
    
    with open(os.path.join(artifacts_path, "rubric.json"), "w") as f:
        json.dump(rubric, f, indent=2)

def generate_report(artifacts_path):
    report = r"""# Architectural Comparison Report: Agentic Frameworks

## 1. Architectural Comparison Matrix

| Dimension | ReAct (Reason + Act) | Plan-and-Execute | Hierarchical Orchestration | State-Machine (DAG) |
|-----------|----------------------|------------------|---------------------------|---------------------|
| **Planning Topology** | Linear / Incremental | Two-stage (Static Plan) | Tree / Recursive | Graph / Deterministic |
| **Control Model** | Decentralized (LLM-led) | Centralized Planner | Hierarchical Delegation | State-based Transitions |
| **Determinism Spectrum** | Low (Stochastic) | Medium (Plan is fixed) | Low (Multi-level stochastic) | High (Defined edges) |
| **Observability/Governance** | Trace-heavy | Plan-centric | Multi-layered | State-transition logs |
| **Enterprise Readiness** | Experimental | Intermediate | Complex | Production-grade |
| **Composition Patterns** | Flat | Sequential | Recursive | Modular / Nested |

## 2. Computational Complexity & Cost Analysis

### ReAct Pattern
- **Complexity**: $O(N)$ where $N$ is the number of reasoning steps.
- **Token Growth**: Linear $O(N \cdot H)$ where $H$ is average history size. Each step appends previous thoughts/actions.
- **Latency**: $L = \sum_{i=1}^N (L_{LLM} + L_{Tool})$. High latency due to sequential LLM calls.
- **Cost**: High token consumption due to repeated context prefixing.

### Plan-and-Execute
- **Complexity**: $O(1)$ planning + $O(E)$ execution steps.
- **Token Growth**: $O(P + E)$ where $P$ is plan size. More efficient as the plan is generated once.
- **Latency**: Lower than ReAct for parallelizable tasks.
- **Cost**: Predictable for the planning phase, variable for execution.

### Hierarchical Multi-Agent
- **Complexity**: $O(B^D)$ where $B$ is branching factor (sub-agents) and $D$ is depth.
- **Token Growth**: Exponential in worst-case if not bounded. $O(\sum B^d)$.
- **Latency**: $L_{max} = D \cdot L_{LLM} + \max(L_{sub-agents})$.
- **Cost**: Highest due to multiple agent overheads and coordination messages.

## 3. Failure Modes

- **ReAct**: Hallucination loops (repeating same failed action), tool output parsing errors.
- **Plan-and-Execute**: "Stale plan" failure where execution environment changes but plan remains static.
- **Hierarchical**: Delegation failure (Manager fails to route to correct worker), context loss across levels.
- **State-Machine**: Deadlock (no valid transition), state explosion.

## 4. Enterprise Deployment Guidance

### Cost Predictability
- Use **Plan-and-Execute** for tasks with known sub-steps to cap planning costs.
- Implement **Token Quotas** at the orchestrator level to prevent runaway ReAct loops.

### Reliability & Constraints
- **Circuit Breakers**: Implement for tool calls to prevent cascading failures.
- **Fallback**: Define deterministic fallbacks (e.g., human escalation) when LLM confidence is low.

### Security & Isolation
- **Sandboxing**: All tool execution (especially code interpreters) MUST run in ephemeral, isolated containers.
- **PII Masking**: Middleware should strip sensitive data before sending to external LLM providers.

### Explainability & Auditability
- **Reasoning Traces**: Store 'Thought' blocks separately for audit.
- **State Snapshots**: In State-Machine topologies, log state transitions to reconstruct decision paths.
"""
    with open(os.path.join(artifacts_path, "architectural_report.md"), "w") as f:
        f.write(report)

if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "artifacts"
    os.makedirs(path, exist_ok=True)
    generate_rubric(path)
    generate_report(path)
