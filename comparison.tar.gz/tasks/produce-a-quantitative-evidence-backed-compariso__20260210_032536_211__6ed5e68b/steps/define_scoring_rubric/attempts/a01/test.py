import json
import os
import pytest

# Paths are relative to the task root
base_path = "steps/define_scoring_rubric/attempts/a01"
artifacts_path = os.path.join(base_path, "artifacts")

def test_rubric_exists():
    assert os.path.exists(os.path.join(artifacts_path, "rubric.json"))

def test_rubric_structure():
    with open(os.path.join(artifacts_path, "rubric.json"), "r") as f:
        data = json.load(f)
    
    assert "categories" in data
    assert len(data["categories"]) >= 5
    
    for cat in data["categories"]:
        assert "name" in cat
        assert "description" in cat
        assert "anchors" in cat
        assert "1" in cat["anchors"]
        assert "5" in cat["anchors"]

def test_report_exists():
    assert os.path.exists(os.path.join(artifacts_path, "architectural_report.md"))

def test_report_content():
    with open(os.path.join(artifacts_path, "architectural_report.md"), "r") as f:
        content = f.read()
    
    # Check for required sections/keywords
    assert "Architectural Comparison Matrix" in content
    assert "Planning Topology" in content
    assert "Control Model" in content
    assert "Complexity" in content
    assert "Failure Modes" in content
    assert "Determinism Spectrum" in content
    assert "Observability/Governance" in content
    assert "Enterprise Deployment Guidance" in content
    assert "Composition Patterns" in content
    
    # Check for formal notation
    assert "O(N)" in content
    assert "O(B^D)" in content
    
    # Check for enterprise guidance details
    assert "Cost Predictability" in content
    assert "Reliability" in content
    assert "Security" in content
    assert "Explainability" in content
