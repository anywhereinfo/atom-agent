import json
import os

def test_msft_evidence_exists():
    path = "steps/gather_msft_evidence/attempts/a01/artifacts/msft_evidence.json"
    assert os.path.exists(path), f"File {path} does not exist"

def test_msft_evidence_content():
    path = "steps/gather_msft_evidence/attempts/a01/artifacts/msft_evidence.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    assert isinstance(data, list), "Evidence should be a list"
    assert len(data) >= 5, f"Expected at least 5 evidence points, found {len(data)}"
    
    categories = [item.get("category") for item in data]
    assert len(set(categories)) >= 3, "Should cover multiple rubric categories"
    
    # Check for SK + AutoGen integration evidence
    integration_evidence = [item for item in data if "Semantic Kernel" in item.get("quote", "") and "AutoGen" in item.get("quote", "")]
    # Or check notes if quote is specific
    integration_evidence_2 = [item for item in data if "SK" in item.get("notes", "") and "AutoGen" in item.get("notes", "")]
    
    assert len(integration_evidence) + len(integration_evidence_2) > 0, "Should contain evidence of SK + AutoGen integration"

    for item in data:
        assert "source" in item
        assert "quote" in item
        assert "category" in item
        assert item["source"].startswith("http"), f"Invalid source URL: {item['source']}"
