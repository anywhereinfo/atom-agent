import json
import os

def gather_evidence():
    evidence = [
        {
            "id": "msft-001",
            "category": "Architecture & Control Model",
            "source": "https://devblogs.microsoft.com/semantic-kernel/microsofts-agentic-ai-frameworks-autogen-and-semantic-kernel/",
            "quote": "This new version [AutoGen 0.4] is a ground up re-design of an event-driven, distributed architecture that is x-language, composable, flexible, observable and scalable.",
            "notes": "Built on Microsoft Orleans, providing a robust actor-based distributed runtime."
        },
        {
            "id": "msft-002",
            "category": "Integration & Ecosystem",
            "source": "https://devblogs.microsoft.com/semantic-kernel/semantic-kernel-and-autogen-part-2/",
            "quote": "AutoGen can now leverage Semantic Kernel connectors to expand functionalities. The following is an example of using Semantic Kernel’s Anthropic AI connector as a model client in AutoGen...",
            "notes": "Demonstrates the SKChatCompletionAdapter which allows AutoGen agents to use SK's extensive connector library."
        },
        {
            "id": "msft-003",
            "category": "Language & Platform Support",
            "source": "https://www.nuget.org/packages/Microsoft.AutoGen.AgentChat/0.4.0-dev.3",
            "quote": "Microsoft.AutoGen.AgentChat 0.4.0-dev.3",
            "notes": "Evidence of first-class .NET support for AutoGen 0.4 via NuGet packages, aligning with Semantic Kernel's strong .NET foundation."
        },
        {
            "id": "msft-004",
            "category": "Integration & Ecosystem",
            "source": "https://microsoft.github.io/autogen/dev//user-guide/agentchat-user-guide/tutorial/models.html",
            "quote": "Azure AI Foundry (previously known as Azure AI Studio) offers models hosted on Azure. To use those models, you use the AzureAIChatCompletionClient.",
            "notes": "Direct integration with Azure AI Foundry for model management and deployment."
        },
        {
            "id": "msft-005",
            "category": "Enterprise Readiness & Governance",
            "source": "https://devblogs.microsoft.com/semantic-kernel/microsofts-agentic-ai-frameworks-autogen-and-semantic-kernel/",
            "quote": "Customers should choose Semantic Kernel if they’re building agent production applications that need AI capabilities with enterprise-grade support.",
            "notes": "Semantic Kernel is positioned as the production-ready, enterprise-supported framework, while AutoGen is for cutting-edge research."
        },
        {
            "id": "msft-006",
            "category": "Scalability & Performance",
            "source": "https://devblogs.microsoft.com/autogen/autogen-reimagined-launching-autogen-0-4/",
            "quote": "Core API: The foundation layer offering a scalable, event-driven actor framework for creating agentic workflows.",
            "notes": "Focus on scalability through the actor model (Orleans)."
        }
    ]

    output_path = "steps/gather_msft_evidence/attempts/a01/artifacts/msft_evidence.json"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with open(output_path, "w") as f:
        json.dump(evidence, f, indent=2)
    
    print(f"Evidence written to {output_path}")

if __name__ == "__main__":
    gather_evidence()
