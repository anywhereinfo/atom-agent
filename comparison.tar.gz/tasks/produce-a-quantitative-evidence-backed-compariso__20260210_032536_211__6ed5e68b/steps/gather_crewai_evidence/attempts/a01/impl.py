import json
import os

def main():
    evidence = {
        "framework": "CrewAI",
        "evidence_points": [
            {
                "category": "Architecture & Topology",
                "point": "Role-Based Agent Design",
                "quote": "CrewAI's framework assigns distinct roles to individual agents, creating specialized teams that mimic the structure of real-world organizations. Each agent operates within its own area of expertise, contributing to collaborative workflows with unique capabilities and decision-making processes.",
                "source": "https://latenode.com/blog/ai-frameworks-technical-infrastructure/crewai-framework/crewai-framework-2025-complete-review-of-the-open-source-multi-agent-ai-platform"
            },
            {
                "category": "Workflow & Orchestration",
                "point": "Sequential and Hierarchical Processes",
                "quote": "Sequential execution ensures tasks are completed in an orderly progression... Hierarchical execution models human team dynamics, with a manager agent overseeing task delegation, reviewing outputs, and coordinating efforts for complex decision-making, task prioritization, and quality control.",
                "source": "https://mgx.dev/insights/crewai-style-role-based-agents-architecture-applications-and-future-trends/b708b00080c34c9bbeb9f680e26fb2d0"
            },
            {
                "category": "Enterprise Readiness & Governance",
                "point": "CrewAI Enterprise Compliance and Security",
                "quote": "Enterprise unlocks certain features and deployment options not available in lower tiers... it's HIPAA and SOC 2 compliant, suitable for regulated industries. You can also choose from on-premise or private cloud deployment... includes advanced admin and governance features: granular role-based access control for users, audit logs, single sign-on integration.",
                "source": "https://www.zenml.io/blog/crewai-pricing"
            },
            {
                "category": "Workflow & Orchestration",
                "point": "CrewAI Flows for State and Event Management",
                "quote": "Flows provide: State Management: Persist data across steps and executions. Event-Driven Execution: Trigger actions based on events or external inputs. Control Flow: Use conditional logic, loops, and branching.",
                "source": "https://docs.crewai.com/en/introduction"
            },
            {
                "category": "Developer Experience",
                "point": "Ease of Use and Visual Design",
                "quote": "Teams can define agents in human readable YAML or use our visual, low code editor to assemble multi step processes that call REST APIs, invoke serverless functions, run Python code, or interface with popular SaaS systems... With one click GitOps pipelines and a unified CLI or UI.",
                "source": "https://aws.amazon.com/marketplace/pp/prodview-e6oyhm2ed6l3c"
            },
            {
                "category": "Enterprise Readiness & Governance",
                "point": "CrewAI AMP (Agent Management Platform)",
                "quote": "CrewAI AMP provides a platform for deploying, monitoring, and scaling your crews and agents in a production environment... features designed for production deployments, collaboration, and scalability. Deploy your crews to a managed infrastructure and monitor their execution in real-time.",
                "source": "https://docs.crewai.com/en/enterprise/introduction"
            }
        ]
    }

    # Ensure the artifacts directory exists
    os.makedirs("steps/gather_crewai_evidence/attempts/a01/artifacts", exist_ok=True)
    
    output_path = "steps/gather_crewai_evidence/attempts/a01/artifacts/crewai_evidence.json"
    with open(output_path, "w") as f:
        json.dump(evidence, f, indent=2)
    
    print(f"Evidence written to {output_path}")

if __name__ == "__main__":
    main()
