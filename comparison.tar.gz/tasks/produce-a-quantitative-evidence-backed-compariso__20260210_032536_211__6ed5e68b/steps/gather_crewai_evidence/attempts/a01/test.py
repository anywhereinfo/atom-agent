import json
import os

def test_crewai_evidence_exists():
    path = "steps/gather_crewai_evidence/attempts/a01/artifacts/crewai_evidence.json"
    assert os.path.exists(path), f"File {path} does not exist"

def test_crewai_evidence_content():
    path = "steps/gather_crewai_evidence/attempts/a01/artifacts/crewai_evidence.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    assert "evidence_points" in data
    assert len(data["evidence_points"]) >= 5
    
    categories = [p["category"] for p in data["evidence_points"]]
    assert "Architecture & Topology" in categories
    assert "Workflow & Orchestration" in categories
    assert "Enterprise Readiness & Governance" in categories
    assert "Developer Experience" in categories

    # Check for Enterprise specific evidence
    enterprise_evidence = [p for p in data["evidence_points"] if "Enterprise" in p["point"] or "Enterprise" in p["quote"]]
    assert len(enterprise_evidence) > 0, "No Enterprise-specific evidence found"

    for point in data["evidence_points"]:
        assert "quote" in point
        assert "source" in point
        assert point["quote"].strip() != ""
        assert point["source"].startswith("http")
