import json
import os
import pytest

def test_weighting_profiles_existence():
    path = "steps/define_weighting_profiles/attempts/a01/artifacts/weighting_profiles.json"
    assert os.path.exists(path), f"{path} does not exist"

def test_summary_existence():
    path = "steps/define_weighting_profiles/attempts/a01/artifacts/profiles_summary.md"
    assert os.path.exists(path), f"{path} does not exist"

def test_weighting_profiles_content():
    path = "steps/define_weighting_profiles/attempts/a01/artifacts/weighting_profiles.json"
    with open(path, "r") as f:
        profiles = json.load(f)
    
    assert len(profiles) >= 3, "Should have at least 3 profiles"
    
    expected_personas = ["Enterprise Architect", "Rapid Prototyper", "AI Researcher"]
    for persona in expected_personas:
        assert persona in profiles, f"Missing persona: {persona}"

    rubric_path = "steps/define_scoring_rubric/committed/artifacts/rubric.json"
    with open(rubric_path, "r") as f:
        rubric = json.load(f)
    
    expected_categories = [cat["name"] for cat in rubric["categories"]]
    
    for name, weights in profiles.items():
        # Check sum
        total = sum(weights.values())
        assert abs(total - 1.0) < 1e-9, f"Profile '{name}' weights sum to {total}, expected 1.0"
        
        # Check categories
        for cat in expected_categories:
            assert cat in weights, f"Category '{cat}' missing in profile '{name}'"
        
        assert len(weights) == len(expected_categories), f"Profile '{name}' has unexpected categories"

def test_persona_priorities():
    path = "steps/define_weighting_profiles/attempts/a01/artifacts/weighting_profiles.json"
    with open(path, "r") as f:
        profiles = json.load(f)
    
    # Enterprise Architect: Prioritizes Enterprise Readiness and Observability
    ea = profiles["Enterprise Architect"]
    assert ea["Enterprise Readiness"] >= 0.3
    assert ea["Observability & Governance"] >= 0.2
    
    # Rapid Prototyper: Prioritizes Ecosystem and Composition
    rp = profiles["Rapid Prototyper"]
    assert rp["Ecosystem & Multi-language Support"] >= 0.3
    assert rp["Composition Patterns"] >= 0.3
    
    # AI Researcher: Prioritizes Topology Control
    ar = profiles["AI Researcher"]
    assert ar["Topology Control"] >= 0.3

def test_analytical_depth():
    path = "steps/define_weighting_profiles/attempts/a01/artifacts/profiles_summary.md"
    with open(path, "r") as f:
        content = f.read()
    
    assert "Failure Scenario" in content
    assert "Production Use Case" in content
    assert "Complexity Analysis" in content
    assert "O(" in content
