import json
import os

def main():
    profiles = {
        "Enterprise Architect": {
            "Observability & Governance": 0.30,
            "Topology Control": 0.10,
            "Enterprise Readiness": 0.40,
            "Ecosystem & Multi-language Support": 0.10,
            "Composition Patterns": 0.10
        },
        "Rapid Prototyper": {
            "Observability & Governance": 0.10,
            "Topology Control": 0.10,
            "Enterprise Readiness": 0.10,
            "Ecosystem & Multi-language Support": 0.35,
            "Composition Patterns": 0.35
        },
        "AI Researcher": {
            "Observability & Governance": 0.25,
            "Topology Control": 0.40,
            "Enterprise Readiness": 0.05,
            "Ecosystem & Multi-language Support": 0.10,
            "Composition Patterns": 0.20
        }
    }

    # Ensure weights sum to 1.0
    for name, weights in profiles.items():
        total = sum(weights.values())
        if abs(total - 1.0) > 1e-9:
            raise ValueError(f"Profile '{name}' weights sum to {total}, expected 1.0")

    output_dir = "steps/define_weighting_profiles/attempts/a01/artifacts"
    os.makedirs(output_dir, exist_ok=True)
    
    output_path = os.path.join(output_dir, "weighting_profiles.json")
    with open(output_path, "w") as f:
        json.dump(profiles, f, indent=4)
    
    print(f"Successfully wrote weighting profiles to {output_path}")

if __name__ == "__main__":
    main()
