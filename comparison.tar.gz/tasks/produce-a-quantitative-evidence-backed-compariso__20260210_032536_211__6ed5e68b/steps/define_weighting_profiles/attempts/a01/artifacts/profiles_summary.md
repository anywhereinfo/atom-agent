# Weighting Profiles Summary

This document describes the three weighting profiles defined for evaluating agentic frameworks.

## 1. Enterprise Architect
**Focus:** Security, Governance, and Scalability.
- **Observability & Governance (0.30):** High priority for audit trails and HITL.
- **Enterprise Readiness (0.40):** Highest priority for multi-tenancy and sandboxing.
- **Topology Control (0.10):** Moderate priority for ensuring deterministic flows.
- **Ecosystem & Multi-language Support (0.10):** Lower priority relative to security.
- **Composition Patterns (0.10):** Lower priority relative to security.

**Production Use Case:** A financial services firm deploying an automated mortgage processing agent that requires strict SOC2 compliance and full auditability of every decision.
**Failure Scenario:** A framework that lacks granular RBAC allows an unauthorized user to modify the agent's tool access, leading to a data breach.

## 2. Rapid Prototyper
**Focus:** Speed of development and ease of integration.
- **Ecosystem & Multi-language Support (0.35):** High priority for pre-built tools and MCP support.
- **Composition Patterns (0.35):** High priority for modularity and reuse.
- **Observability & Governance (0.10):** Lower priority during early development.
- **Topology Control (0.10):** Lower priority; flexibility is preferred over strictness.
- **Enterprise Readiness (0.10):** Lower priority for initial MVPs.

**Production Use Case:** A startup building a customer support bot MVP that needs to integrate with Slack, Jira, and Zendesk using existing libraries in under a week.
**Failure Scenario:** A framework with a steep learning curve and proprietary DSL prevents the developer from quickly swapping out a tool, delaying the product launch.

## 3. AI Researcher
**Focus:** Control over agent behavior and experimental observability.
- **Topology Control (0.40):** Highest priority for experimenting with complex multi-agent interactions.
- **Observability & Governance (0.25):** High priority for debugging and tracing agent reasoning.
- **Composition Patterns (0.20):** High priority for recursive agent nesting.
- **Ecosystem & Multi-language Support (0.10):** Moderate priority.
- **Enterprise Readiness (0.05):** Lowest priority; focus is on capability, not production hardening.

**Production Use Case:** An AI lab testing a new hierarchical planning algorithm where agents must dynamically delegate tasks to sub-agents with precise state transitions.
**Failure Scenario:** A framework with "magic" black-box orchestration makes it impossible to diagnose why an agent entered an infinite loop during a complex reasoning task.

## Complexity Analysis
The weighting profiles use a linear combination model:
Score = Σ (Weight_i * Rating_i)
Computational complexity of scoring a single framework is O(N) where N is the number of criteria.
For M frameworks and P profiles, the total complexity is O(M * P * N).
Given N=5, P=3, and M=3 (Microsoft, CrewAI, LangGraph), this is negligible.
