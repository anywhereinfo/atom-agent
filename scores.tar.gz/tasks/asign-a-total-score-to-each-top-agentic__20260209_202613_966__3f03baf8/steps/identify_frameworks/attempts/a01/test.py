import json
import os
import pytest

ARTIFACTS_DIR = "steps/identify_frameworks/attempts/a01/artifacts"
JSON_PATH = os.path.join(ARTIFACTS_DIR, "frameworks.json")

def test_frameworks_json_exists():
    assert os.path.exists(JSON_PATH), f"frameworks.json does not exist at {JSON_PATH}"

def test_frameworks_content():
    with open(JSON_PATH, "r") as f:
        data = json.load(f)
    
    assert isinstance(data, list), "Content is not a JSON list"
    assert len(data) >= 5, "List must contain at least 5 frameworks"
    
    for item in data:
        assert "name" in item, f"Missing 'name' in item: {item}"
        assert "repo_url" in item, f"Missing 'repo_url' in item: {item}"
        assert isinstance(item["name"], str), "Name must be a string"
        assert isinstance(item["repo_url"], str), "Repo URL must be a string"
        assert item["repo_url"].startswith("http"), "Repo URL must start with http"

if __name__ == "__main__":
    pytest.main([__file__])
