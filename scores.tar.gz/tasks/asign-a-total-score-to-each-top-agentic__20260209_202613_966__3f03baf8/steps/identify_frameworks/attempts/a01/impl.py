import json
import os

def main():
    frameworks = [
        {
            "name": "LangChain",
            "repo_url": "https://github.com/langchain-ai/langchain",
            "description": "Building applications with LLMs through composability"
        },
        {
            "name": "AutoGen",
            "repo_url": "https://github.com/microsoft/autogen",
            "description": "A programming framework for agentic AI"
        },
        {
            "name": "CrewAI",
            "repo_url": "https://github.com/crewAIInc/crewAI",
            "description": "Framework for orchestrating role-playing, autonomous AI agents"
        },
        {
            "name": "MetaGPT",
            "repo_url": "https://github.com/geekan/MetaGPT",
            "description": "The Multi-Agent Framework: Given one line Requirement, return PRD, Design, Tasks, Repo"
        },
        {
            "name": "LlamaIndex",
            "repo_url": "https://github.com/run-llama/llama_index",
            "description": "Data framework for your LLM applications"
        }
    ]

    # Define the target directory relative to the task root
    target_dir = "steps/identify_frameworks/attempts/a01/artifacts"
    
    # Ensure directory exists
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    output_path = os.path.join(target_dir, "frameworks.json")
    
    with open(output_path, "w") as f:
        json.dump(frameworks, f, indent=2)
    
    print(f"Successfully wrote {len(frameworks)} frameworks to {output_path}")

if __name__ == "__main__":
    main()
