import pytest
import json
import os

ARTIFACTS_DIR = os.path.join(os.path.dirname(__file__), "artifacts")
RUBRIC_PATH = os.path.join(ARTIFACTS_DIR, "rubric.json")

def test_rubric_file_exists():
    assert os.path.exists(RUBRIC_PATH), f"rubric.json not found at {RUBRIC_PATH}"

def test_rubric_structure():
    with open(RUBRIC_PATH, "r") as f:
        rubric = json.load(f)
    
    assert "maturity" in rubric, "Missing 'maturity' category"
    assert "capabilities" in rubric, "Missing 'capabilities' category"
    
    assert isinstance(rubric["maturity"], dict)
    assert isinstance(rubric["capabilities"], dict)

def test_maturity_metrics():
    with open(RUBRIC_PATH, "r") as f:
        rubric = json.load(f)
    
    metrics = rubric["maturity"].get("metrics", {})
    assert len(metrics) > 0, "Maturity category has no metrics"
    
    # Check for specific expected metrics (example)
    assert "github_stars" in metrics
    assert "documentation_quality" in metrics
    
    for key, val in metrics.items():
        assert "max_points" in val, f"Metric {key} missing max_points"
        assert isinstance(val["max_points"], (int, float)), f"Metric {key} max_points is not a number"
        assert "scoring_logic" in val, f"Metric {key} missing scoring_logic"

def test_capabilities_metrics():
    with open(RUBRIC_PATH, "r") as f:
        rubric = json.load(f)
    
    metrics = rubric["capabilities"].get("metrics", {})
    assert len(metrics) > 0, "Capabilities category has no metrics"
    
    # Check for specific expected metrics
    assert "multi_agent_orchestration" in metrics
    assert "tool_integration" in metrics
    
    for key, val in metrics.items():
        assert "max_points" in val, f"Metric {key} missing max_points"
        assert isinstance(val["max_points"], (int, float)), f"Metric {key} max_points is not a number"
        assert "scoring_logic" in val, f"Metric {key} missing scoring_logic"
