import json
import os

def generate_rubric():
    rubric = {
        "maturity": {
            "description": "Evaluates the stability, adoption, and maintenance of the framework.",
            "metrics": {
                "github_stars": {
                    "description": "Number of GitHub stars as a proxy for popularity.",
                    "max_points": 10,
                    "scoring_logic": ">10k: 10, >5k: 7, >1k: 4, <1k: 1"
                },
                "documentation_quality": {
                    "description": "Completeness and clarity of documentation.",
                    "max_points": 10,
                    "scoring_logic": "Excellent (Examples+API): 10, Good: 7, Basic: 4, Poor: 1"
                },
                "active_maintenance": {
                    "description": "Recency of commits and release frequency.",
                    "max_points": 10,
                    "scoring_logic": "Commit <1 week: 10, <1 month: 7, <6 months: 4, >6 months: 1"
                },
                "community_support": {
                    "description": "Activity in issues, discussions, or Discord.",
                    "max_points": 5,
                    "scoring_logic": "High: 5, Moderate: 3, Low: 1"
                }
            }
        },
        "capabilities": {
            "description": "Evaluates the technical features and flexibility of the framework.",
            "metrics": {
                "multi_agent_orchestration": {
                    "description": "Native support for multiple agents interacting.",
                    "max_points": 10,
                    "scoring_logic": "Native/Robust: 10, Basic/Manual: 5, None: 0"
                },
                "tool_integration": {
                    "description": "Ease of integrating external tools and APIs.",
                    "max_points": 10,
                    "scoring_logic": "Extensive/Standardized: 10, Basic: 5, Limited: 0"
                },
                "memory_management": {
                    "description": "Capabilities for short-term and long-term memory.",
                    "max_points": 10,
                    "scoring_logic": "Persistent/Database: 10, In-memory/Simple: 5, None: 0"
                },
                "llm_flexibility": {
                    "description": "Support for various LLM providers (OpenAI, Anthropic, Local, etc.).",
                    "max_points": 5,
                    "scoring_logic": "Agnostic/Many: 5, Limited: 2, Single Vendor: 0"
                },
                "ease_of_use": {
                    "description": "Developer experience and learning curve.",
                    "max_points": 5,
                    "scoring_logic": "High-level API: 5, Moderate: 3, Complex: 1"
                }
            }
        }
    }

    # Ensure artifacts directory exists
    output_dir = os.path.join(os.path.dirname(__file__), "artifacts")
    os.makedirs(output_dir, exist_ok=True)
    
    output_path = os.path.join(output_dir, "rubric.json")
    with open(output_path, "w") as f:
        json.dump(rubric, f, indent=2)
    
    print(f"Rubric generated at {output_path}")

if __name__ == "__main__":
    generate_rubric()
