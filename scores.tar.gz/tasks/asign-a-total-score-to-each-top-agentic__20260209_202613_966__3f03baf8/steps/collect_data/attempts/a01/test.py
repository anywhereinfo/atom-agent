import json
import os
import sys
import pytest
import subprocess

# Add current directory to path so we can import impl if needed, but we'll run it as a subprocess
sys.path.append(os.path.dirname(__file__))

def test_collect_metrics():
    # Run implementation
    result = subprocess.run(["python3", "steps/collect_data/attempts/a01/impl.py"], capture_output=True, text=True)
    print(result.stdout)
    print(result.stderr)
    assert result.returncode == 0, "Implementation script failed"

    # Verify artifact exists
    output_path = "steps/collect_data/attempts/a01/artifacts/framework_metrics.json"
    assert os.path.exists(output_path), "Artifact framework_metrics.json not created"

    # Load artifact
    with open(output_path, 'r') as f:
        metrics = json.load(f)

    # Load dependencies for validation
    frameworks_path = "steps/identify_frameworks/committed/artifacts/frameworks.json"
    rubric_path = "steps/define_rubric/committed/artifacts/rubric.json"
    
    with open(frameworks_path, 'r') as f:
        frameworks = json.load(f)
    
    with open(rubric_path, 'r') as f:
        rubric = json.load(f)

    # Validate all frameworks are present
    framework_names = [fw['name'] for fw in frameworks]
    for name in framework_names:
        assert name in metrics, f"Missing metrics for framework: {name}"

    # Validate structure matches rubric
    capability_metrics = list(rubric['capabilities']['metrics'].keys())
    maturity_metrics = list(rubric['maturity']['metrics'].keys())

    for name, data in metrics.items():
        assert "capabilities" in data, f"Missing capabilities for {name}"
        assert "maturity" in data, f"Missing maturity for {name}"

        for metric in capability_metrics:
            assert metric in data["capabilities"], f"Missing capability metric {metric} for {name}"
        
        for metric in maturity_metrics:
            assert metric in data["maturity"], f"Missing maturity metric {metric} for {name}"

if __name__ == "__main__":
    pytest.main([__file__])
