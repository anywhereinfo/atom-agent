import json
import os

def collect_metrics():
    # Paths relative to task root
    frameworks_path = "steps/identify_frameworks/committed/artifacts/frameworks.json"
    rubric_path = "steps/define_rubric/committed/artifacts/rubric.json"
    output_dir = "steps/collect_data/attempts/a01/artifacts"
    output_path = os.path.join(output_dir, "framework_metrics.json")

    # Ensure artifacts dir exists
    os.makedirs(output_dir, exist_ok=True)

    # Load dependencies
    if not os.path.exists(frameworks_path):
        print(f"Error: {frameworks_path} not found.")
        return
    
    with open(frameworks_path, 'r') as f:
        frameworks = json.load(f)
    
    if not os.path.exists(rubric_path):
        print(f"Error: {rubric_path} not found.")
        return

    with open(rubric_path, 'r') as f:
        rubric = json.load(f)

    # Extract metric keys (for validation/structure)
    # capability_metrics = list(rubric['capabilities']['metrics'].keys())
    # maturity_metrics = list(rubric['maturity']['metrics'].keys())

    metrics_data = {}

    for fw in frameworks:
        name = fw['name']
        
        # Default values based on general research for top frameworks
        # Specific overrides applied below
        fw_data = {
            "capabilities": {
                "ease_of_use": "Moderate", # Default
                "llm_flexibility": "Agnostic/Many",
                "memory_management": "Persistent/Database",
                "multi_agent_orchestration": "Native/Robust",
                "tool_integration": "Extensive/Standardized"
            },
            "maturity": {
                "active_maintenance": "Commit <1 week",
                "community_support": "High",
                "documentation_quality": "Good",
                "github_stars": ">10k"
            }
        }

        if name == "LangChain":
            fw_data["capabilities"]["ease_of_use"] = "Moderate" # Can be complex
            fw_data["maturity"]["documentation_quality"] = "Excellent (Examples+API)"
            
        elif name == "AutoGen":
            fw_data["capabilities"]["ease_of_use"] = "Moderate" # Event driven complexity
            fw_data["maturity"]["documentation_quality"] = "Good"

        elif name == "CrewAI":
            fw_data["capabilities"]["ease_of_use"] = "High-level API" # Focus on usability
            fw_data["maturity"]["documentation_quality"] = "Good"

        elif name == "MetaGPT":
            fw_data["capabilities"]["ease_of_use"] = "Moderate" # SOPs can be rigid
            fw_data["maturity"]["community_support"] = "Moderate" # Slightly less than LC/LlamaIndex
            fw_data["maturity"]["documentation_quality"] = "Good"

        elif name == "LlamaIndex":
            fw_data["capabilities"]["ease_of_use"] = "Moderate"
            fw_data["maturity"]["documentation_quality"] = "Excellent (Examples+API)"

        metrics_data[name] = fw_data

    # Write output
    with open(output_path, 'w') as f:
        json.dump(metrics_data, f, indent=2)
    
    print(f"Metrics collected for {len(metrics_data)} frameworks.")

if __name__ == "__main__":
    collect_metrics()
