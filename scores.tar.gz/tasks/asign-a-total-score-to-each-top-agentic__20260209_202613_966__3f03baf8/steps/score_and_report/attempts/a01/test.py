import os
import json
import sys
import pytest

# Add the attempt directory to sys.path so we can import impl
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

import impl

def test_score_and_report_execution():
    # Define paths
    rubric_path = "steps/define_rubric/committed/artifacts/rubric.json"
    metrics_path = "steps/collect_data/committed/artifacts/framework_metrics.json"
    output_json_path = "steps/score_and_report/attempts/a01/artifacts/scored_frameworks.json"
    output_md_path = "steps/score_and_report/attempts/a01/artifacts/report.md"

    # Ensure input files exist
    assert os.path.exists(rubric_path), f"Rubric file not found at {rubric_path}"
    assert os.path.exists(metrics_path), f"Metrics file not found at {metrics_path}"

    # Run the implementation
    try:
        impl.main()
    except Exception as e:
        pytest.fail(f"Implementation failed with error: {e}")

    # Verify artifacts are created
    assert os.path.exists(output_json_path), "scored_frameworks.json was not created"
    assert os.path.exists(output_md_path), "report.md was not created"

    # Verify JSON content structure
    with open(output_json_path, 'r') as f:
        data = json.load(f)
    
    assert isinstance(data, dict), "Output JSON should be a dictionary"
    assert len(data) > 0, "Output JSON should not be empty"

    for framework, scores in data.items():
        assert "maturity_score" in scores, f"Missing maturity_score for {framework}"
        assert "capabilities_score" in scores, f"Missing capabilities_score for {framework}"
        assert "total_score" in scores, f"Missing total_score for {framework}"
        assert "details" in scores, f"Missing details for {framework}"
        assert "maturity" in scores["details"], f"Missing maturity details for {framework}"
        assert "capabilities" in scores["details"], f"Missing capabilities details for {framework}"

    # Verify Markdown content
    with open(output_md_path, 'r') as f:
        md_content = f.read()
    
    assert "# Framework Evaluation Report" in md_content
    assert "Maturity Score" in md_content
    assert "Capabilities Score" in md_content
    assert "Total Score" in md_content

if __name__ == "__main__":
    # Manually run the test function if executed directly
    try:
        test_score_and_report_execution()
        print("Test passed!")
    except AssertionError as e:
        print(f"Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(1)
