import json
import os

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def parse_scoring_logic(logic_str):
    """
    Parses a scoring logic string like "Key: Value, Key2: Value2" into a dictionary.
    """
    mapping = {}
    parts = logic_str.split(',')
    for part in parts:
        if ':' in part:
            key, value = part.rsplit(':', 1)
            mapping[key.strip()] = int(value.strip())
    return mapping

def calculate_scores(rubric, metrics):
    scored_frameworks = {}

    for framework, framework_data in metrics.items():
        framework_scores = {
            "maturity_score": 0,
            "capabilities_score": 0,
            "total_score": 0,
            "details": {
                "maturity": {},
                "capabilities": {}
            }
        }

        # Process Maturity
        if "maturity" in rubric and "maturity" in framework_data:
            for metric, metric_def in rubric["maturity"]["metrics"].items():
                scoring_map = parse_scoring_logic(metric_def["scoring_logic"])
                metric_value = framework_data["maturity"].get(metric)
                
                score = 0
                if metric_value in scoring_map:
                    score = scoring_map[metric_value]
                else:
                    # Fallback or error handling? For now, 0 if not found, but let's try to be robust
                    # Maybe the value in metrics has extra spaces?
                    # Let's try stripping
                    if metric_value:
                        score = scoring_map.get(metric_value.strip(), 0)
                
                framework_scores["details"]["maturity"][metric] = score
                framework_scores["maturity_score"] += score

        # Process Capabilities
        if "capabilities" in rubric and "capabilities" in framework_data:
            for metric, metric_def in rubric["capabilities"]["metrics"].items():
                scoring_map = parse_scoring_logic(metric_def["scoring_logic"])
                metric_value = framework_data["capabilities"].get(metric)
                
                score = 0
                if metric_value in scoring_map:
                    score = scoring_map[metric_value]
                else:
                    if metric_value:
                        score = scoring_map.get(metric_value.strip(), 0)
                
                framework_scores["details"]["capabilities"][metric] = score
                framework_scores["capabilities_score"] += score

        framework_scores["total_score"] = framework_scores["maturity_score"] + framework_scores["capabilities_score"]
        scored_frameworks[framework] = framework_scores

    return scored_frameworks

def generate_report(scored_frameworks):
    # Sort frameworks by total score descending
    sorted_frameworks = sorted(scored_frameworks.items(), key=lambda x: x[1]['total_score'], reverse=True)

    report_lines = []
    report_lines.append("# Framework Evaluation Report")
    report_lines.append("")
    report_lines.append("## Summary Ranking")
    report_lines.append("| Rank | Framework | Total Score | Maturity Score | Capabilities Score |")
    report_lines.append("|---|---|---|---|---|")
    
    for rank, (name, scores) in enumerate(sorted_frameworks, 1):
        report_lines.append(f"| {rank} | {name} | {scores['total_score']} | {scores['maturity_score']} | {scores['capabilities_score']} |")
    
    report_lines.append("")
    report_lines.append("## Detailed Breakdown")
    
    for name, scores in sorted_frameworks:
        report_lines.append(f"### {name} (Total: {scores['total_score']})")
        report_lines.append(f"**Maturity Score:** {scores['maturity_score']}")
        report_lines.append("| Metric | Score |")
        report_lines.append("|---|---|")
        for metric, score in scores['details']['maturity'].items():
            report_lines.append(f"| {metric} | {score} |")
        
        report_lines.append("")
        report_lines.append(f"**Capabilities Score:** {scores['capabilities_score']}")
        report_lines.append("| Metric | Score |")
        report_lines.append("|---|---|")
        for metric, score in scores['details']['capabilities'].items():
            report_lines.append(f"| {metric} | {score} |")
        report_lines.append("")

    return "\n".join(report_lines)

def main():
    # Paths
    rubric_path = "steps/define_rubric/committed/artifacts/rubric.json"
    metrics_path = "steps/collect_data/committed/artifacts/framework_metrics.json"
    output_json_path = "steps/score_and_report/attempts/a01/artifacts/scored_frameworks.json"
    output_md_path = "steps/score_and_report/attempts/a01/artifacts/report.md"

    # Load data
    rubric = load_json(rubric_path)
    metrics = load_json(metrics_path)

    # Calculate scores
    scored_frameworks = calculate_scores(rubric, metrics)

    # Write JSON output
    with open(output_json_path, 'w') as f:
        json.dump(scored_frameworks, f, indent=2)

    # Generate and write Markdown report
    report_content = generate_report(scored_frameworks)
    with open(output_md_path, 'w') as f:
        f.write(report_content)

    print(f"Successfully generated {output_json_path} and {output_md_path}")

if __name__ == "__main__":
    main()
