import os
import json
import pytest

ARTIFACTS_PATH = "steps/failure_and_reliability_analysis/attempts/a01/artifacts/"

def test_artifacts_exist():
    assert os.path.exists(os.path.join(ARTIFACTS_PATH, "failure_analysis.json"))
    assert os.path.exists(os.path.join(ARTIFACTS_PATH, "reliability_analysis.md"))

def test_failure_analysis_content():
    with open(os.path.join(ARTIFACTS_PATH, "failure_analysis.json"), "r") as f:
        data = json.load(f)
    
    strategies = ["linear_cot", "tree_of_thought", "hierarchical_planning", "reactive_react", "multi_agent"]
    for s in strategies:
        assert s in data
        assert "failure_scenario" in data[s]
        assert len(data[s]["failure_scenario"]) > 20

def test_reliability_report_sections():
    with open(os.path.join(ARTIFACTS_PATH, "reliability_analysis.md"), "r") as f:
        content = f.read()
    
    required_headers = [
        "Failure Propagation and Mitigation",
        "Determinism Spectrum",
        "Observability and Governance Surface",
        "Architectural Comparison Matrix",
        "Complexity and Cost Analysis",
        "Enterprise Deployment Guidance"
    ]
    for header in required_headers:
        assert header in content

def test_complexity_notation():
    with open(os.path.join(ARTIFACTS_PATH, "reliability_analysis.md"), "r") as f:
        content = f.read()
    
    # Check for formal complexity notation
    assert "$O(L)$" in content
    assert "$O(b^d)$" in content
    assert "$O(N" in content # Hierarchical notation

def test_determinism_spectrum():
    with open(os.path.join(ARTIFACTS_PATH, "reliability_analysis.md"), "r") as f:
        content = f.read()
    
    assert "Stochastic" in content
    assert "Deterministic" in content

def test_enterprise_guidance():
    with open(os.path.join(ARTIFACTS_PATH, "reliability_analysis.md"), "r") as f:
        content = f.read()
    
    assert "Cost Predictability" in content
    assert "Reliability Constraints" in content
    assert "Security and Isolation" in content
    assert "Explainability and Auditability" in content
