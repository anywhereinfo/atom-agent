import json
import os
import pytest

def test_taxonomy_exists():
    path = "steps/taxonomy_and_formal_modeling/attempts/a01/artifacts/taxonomy.json"
    assert os.path.exists(path)

def test_taxonomy_content():
    path = "steps/taxonomy_and_formal_modeling/attempts/a01/artifacts/taxonomy.json"
    with open(path, "r") as f:
        data = json.load(f)
    assert "strategies" in data
    assert len(data["strategies"]) >= 5
    for strategy in data["strategies"]:
        assert "name" in strategy
        assert "topology" in strategy
        assert "control_model" in strategy

def test_formal_models_exists():
    path = "steps/taxonomy_and_formal_modeling/attempts/a01/artifacts/formal_models.md"
    assert os.path.exists(path)

def test_formal_models_content():
    path = "steps/taxonomy_and_formal_modeling/attempts/a01/artifacts/formal_models.md"
    with open(path, "r") as f:
        content = f.read()
    
    # Check for strategy headers
    strategies = ["Chain of Thought", "ReAct", "Tree of Thoughts", "Plan-and-Execute", "MCTS-based"]
    for strategy in strategies:
        assert strategy in content
    
    # Check for required formal modeling sections
    required_sections = ["State Space", "Transition Logic", "Planning Topology", "Control Model", "Complexity", "Failure Modes"]
    for section in required_sections:
        assert section in content

def test_analytical_depth():
    path = "steps/taxonomy_and_formal_modeling/attempts/a01/artifacts/formal_models.md"
    with open(path, "r") as f:
        content = f.read()
    
    # Check for composition patterns
    assert "Composition Pattern" in content
    
    # Check for systems-level dimensions
    assert "Determinism" in content
    assert "Observability" in content
    assert "Production Readiness" in content
    
    # Check for complexity notation (O(n) or O(b^d))
    assert "O(" in content
