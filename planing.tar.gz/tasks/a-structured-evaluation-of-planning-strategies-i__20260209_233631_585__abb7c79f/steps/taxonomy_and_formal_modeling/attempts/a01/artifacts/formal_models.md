# Formal Modeling of Planning Strategies

## 1. Chain of Thought (CoT)
- **State Space ($S$):** $S = \{t_1, t_2, ..., t_n, a\}$, where $t_i$ are reasoning tokens/thoughts and $a$ is the final answer.
- **Transition Logic ($T$):** $T: S_{current} 	o S_{next}$ based on internal model weights.
- **Planning Topology:** Linear.
- **Control Model:** Predictive/Open-loop.
- **Complexity:** $O(N)$ where $N$ is the number of steps.
- **Failure Modes:** Error accumulation (hallucination drift), inability to correct mid-course.
- **Composition Pattern:** Often used as a primitive within larger frameworks (e.g., as the 'Reason' part of ReAct).

## 2. ReAct (Reason + Act)
- **State Space ($S$):** $S = \{T, A, O\}$, where $T$ = Thought, $A$ = Action, $O$ = Observation.
- **Transition Logic ($T$):** $T(T_i, A_i, O_i) 	o T_{i+1}$. The model consumes the observation from the environment to generate the next thought.
- **Planning Topology:** Linear/Iterative.
- **Control Model:** Reactive/Closed-loop.
- **Complexity:** $O(N 	imes (Cost_{LLM} + Latency_{Env}))$.
- **Failure Modes:** Infinite loops, observation misinterpretation, tool failure.
- **Composition Pattern:** Can be wrapped in a 'Plan-and-Execute' loop where each sub-task is a ReAct session.

## 3. Tree of Thoughts (ToT)
- **State Space ($S$):** A tree where each node $s$ is a partial solution or thought.
- **Transition Logic ($T$):** $T(s) 	o \{s'_1, s'_2, ..., s'_k\}$ (BFS/DFS expansion).
- **Evaluation ($V$):** $V(s) \in [0, 1]$ or {Correct, Incorrect, Possible}.
- **Planning Topology:** Tree.
- **Control Model:** Predictive/Closed-loop (internal feedback).
- **Complexity:** $O(b^d)$ where $b$ is branching factor and $d$ is depth.
- **Failure Modes:** Combinatorial explosion, poor heuristic evaluation leading to pruning correct paths.
- **Composition Pattern:** Used for complex creative or mathematical tasks requiring backtracking.

## 4. Plan-and-Execute
- **State Space ($S$):** $S_{planner} = \{P\}$, where $P = \{task_1, ..., task_n\}$. $S_{executor} = \{status_i\}$.
- **Transition Logic ($T$):** 
    1. $T_{plan}(Goal) 	o P$
    2. $T_{exec}(task_i) 	o status_i$
    3. If $status_i == Fail$, $T_{replanner}(P, status_i) 	o P'$.
- **Planning Topology:** Hierarchical/Linear.
- **Control Model:** Predictive (Plan) + Reactive (Execute).
- **Complexity:** $O(N_{tasks} + N_{replans})$.
- **Failure Modes:** Rigid initial plans, high cost of frequent re-planning.
- **Composition Pattern:** Orchestrator-Worker pattern.

## 5. MCTS-based Planning
- **State Space ($S$):** $S = \{Nodes\}$ representing world states or decision points.
- **Transition Logic ($T$):** Four phases: Selection (UCB1), Expansion, Simulation (Rollout), Backpropagation.
- **Planning Topology:** Tree/Graph.
- **Control Model:** Predictive/Closed-loop.
- **Complexity:** $O(I 	imes D)$ where $I$ is iterations and $D$ is simulation depth.
- **Failure Modes:** High computational cost (many LLM calls), simulation bias.
- **Composition Pattern:** Used in high-stakes decision making or competitive games.

## Composition Patterns & Systems-Level Dimensions
- **Determinism:** Most LLM planning is stochastic. MCTS and ToT attempt to impose structure but rely on stochastic LLM outputs for node generation.
- **Observability:** ReAct provides high observability via trace logs. CoT is observable but non-intervenable.
- **Production Readiness:** Plan-and-Execute is most common in enterprise due to cost control. ToT/MCTS are often too expensive for real-time applications.
