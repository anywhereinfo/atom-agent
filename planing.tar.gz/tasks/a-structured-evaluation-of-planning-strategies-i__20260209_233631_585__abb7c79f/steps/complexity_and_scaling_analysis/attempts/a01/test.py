import json
import os
import pytest

def test_artifacts_exist():
    base_path = "steps/complexity_and_scaling_analysis/attempts/a01/artifacts"
    assert os.path.exists(f"{base_path}/complexity_analysis.json")
    assert os.path.exists(f"{base_path}/scaling_report.md")

def test_complexity_analysis_content():
    base_path = "steps/complexity_and_scaling_analysis/attempts/a01/artifacts"
    with open(f"{base_path}/complexity_analysis.json", "r") as f:
        data = json.load(f)
    
    assert "strategies" in data
    strategies = data["strategies"]
    assert len(strategies) >= 5
    
    for strategy in strategies:
        assert "name" in strategy
        assert "complexity_notation" in strategy
        assert "O(" in strategy["complexity_notation"]
        assert "topology" in strategy
        assert "token_growth" in strategy
        assert "latency_amplification" in strategy

def test_scaling_report_content():
    base_path = "steps/complexity_and_scaling_analysis/attempts/a01/artifacts"
    with open(f"{base_path}/scaling_report.md", "r") as f:
        content = f.read()
    
    # Check for required sections
    assert "Architectural Comparison Matrix" in content
    assert "Detailed Scaling Analysis" in content
    assert "Failure Scenarios and Production Use Cases" in content
    assert "Enterprise Deployment Guidance" in content
    
    # Check for matrix dimensions
    matrix_dimensions = [
        "Planning Topology",
        "Control Model",
        "Complexity",
        "Failure Modes",
        "Determinism",
        "Observability",
        "Enterprise Readiness",
        "Composition"
    ]
    for dim in matrix_dimensions:
        assert dim in content

    # Check for specific analysis
    assert "Token Growth and Cost Analysis" in content
    assert "Latency Amplification" in content
    assert "Memory and Context Scaling" in content
    
    # Check for enterprise guidance
    assert "Cost Predictability" in content
    assert "Reliability and Constraints" in content
    assert "Security and Isolation" in content
    assert "Explainability and Auditability" in content

    # Check for Big-O in report
    assert "O(d)" in content
    assert "O(b^d)" in content

def test_failure_scenarios_and_use_cases():
    base_path = "steps/complexity_and_scaling_analysis/attempts/a01/artifacts"
    with open(f"{base_path}/scaling_report.md", "r") as f:
        content = f.read()
    
    # Split by section 4
    if "## 4. Failure Scenarios and Production Use Cases" not in content:
        pytest.fail("Section 4 not found")
    
    section_4 = content.split("## 4. Failure Scenarios and Production Use Cases")[1]
    # Also split by section 5 to isolate section 4
    section_4 = section_4.split("## 5. Enterprise Deployment Guidance")[0]

    strategies = ["Chain-of-Thought", "ReAct", "Plan-and-Execute", "Tree-of-Thoughts", "Reflexion"]
    for strategy in strategies:
        assert strategy in section_4
        # Check for failure scenario and use case for each
        strategy_section = section_4.split(strategy)[1]
        assert "Failure Scenario" in strategy_section
        assert "Production Use Case" in strategy_section

if __name__ == "__main__":
    pytest.main([__file__])
