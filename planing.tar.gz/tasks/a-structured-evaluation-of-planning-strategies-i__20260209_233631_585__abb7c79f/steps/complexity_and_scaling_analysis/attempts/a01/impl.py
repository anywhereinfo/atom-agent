import json
import os

def generate_artifacts():
    base_path = "steps/complexity_and_scaling_analysis/attempts/a01/artifacts"
    os.makedirs(base_path, exist_ok=True)

    # 1. Complexity Analysis JSON
    complexity_data = {
        "strategies": [
            {
                "name": "Chain-of-Thought (CoT)",
                "topology": "Linear",
                "complexity_notation": "O(d)",
                "parameters": {
                    "d": "Number of reasoning steps"
                },
                "token_growth": "Linear: T_total = T_prompt + d * T_step",
                "latency_amplification": "Linear: L_total = d * L_inference",
                "memory_scaling": "O(d) context window usage",
                "tool_overhead": "None (intrinsic reasoning)",
                "branching_factor": 1
            },
            {
                "name": "ReAct (Reason + Act)",
                "topology": "Iterative / State Machine",
                "complexity_notation": "O(d * (t + r))",
                "parameters": {
                    "d": "Number of interaction loops",
                    "t": "Tool execution time/tokens",
                    "r": "Reasoning step tokens"
                },
                "token_growth": "Linear with step count, but additive per tool response",
                "latency_amplification": "High: Sequential dependency on tool I/O",
                "memory_scaling": "O(d) - history accumulates in context",
                "tool_overhead": "High: Depends on tool response size",
                "branching_factor": 1
            },
            {
                "name": "Plan-and-Execute",
                "topology": "Two-Stage (Sequential)",
                "complexity_notation": "O(P + E)",
                "parameters": {
                    "P": "Planning complexity (usually O(d_plan))",
                    "E": "Execution complexity (usually O(d_exec))"
                },
                "token_growth": "Bimodal: Large planning burst, then sequential execution tokens",
                "latency_amplification": "Moderate: Parallel execution possible for independent sub-tasks",
                "memory_scaling": "O(max(P, E)) if state is managed efficiently",
                "tool_overhead": "Moderate: Tool calls are pre-planned",
                "branching_factor": 1
            },
            {
                "name": "Tree-of-Thoughts (ToT)",
                "topology": "Tree Search",
                "complexity_notation": "O(b^d)",
                "parameters": {
                    "b": "Branching factor (number of thoughts per step)",
                    "d": "Search depth"
                },
                "token_growth": "Exponential: T_total = sum_{i=1}^d b^i * T_thought",
                "latency_amplification": "Very High: Sequential levels, though branches can be parallelized",
                "memory_scaling": "O(b^d) or O(b*d) depending on search algorithm (BFS vs DFS)",
                "tool_overhead": "Very High: If tools are used at each node",
                "branching_factor": "b > 1"
            },
            {
                "name": "Reflexion / Self-Refine",
                "topology": "Cyclic / Feedback Loop",
                "complexity_notation": "O(k * d)",
                "parameters": {
                    "k": "Number of refinement iterations",
                    "d": "Complexity of the base task"
                },
                "token_growth": "Linear-Iterative: T_total = sum_{i=1}^k (T_output_i + T_critique_i)",
                "latency_amplification": "High: Sequential feedback loops",
                "memory_scaling": "O(k * d) if full history is kept",
                "tool_overhead": "Moderate: Usually involves verification tools",
                "branching_factor": 1
            }
        ]
    }

    with open(f"{base_path}/complexity_analysis.json", "w") as f:
        json.dump(complexity_data, f, indent=2)

    # 2. Scaling Report Markdown
    scaling_report = """# Computational Complexity and Scaling Analysis Report

## 1. Executive Summary
This report analyzes the scaling behavior, computational complexity, and enterprise implications of various LLM planning strategies. As task complexity increases, the choice of planning topology significantly impacts latency, cost, and reliability.

## 2. Architectural Comparison Matrix

| Dimension | CoT | ReAct | Plan-and-Execute | Tree-of-Thoughts | Reflexion |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Planning Topology** | Linear | Iterative | Two-Stage | Tree Search | Cyclic |
| **Control Model** | Implicit | Reactive | Proactive | Search-based | Evaluative |
| **Complexity** | O(d) | O(d * (t+r)) | O(P + E) | O(b^d) | O(k * d) |
| **Determinism** | Low | Low | Medium | High (with pruning) | Medium |
| **Failure Modes** | Hallucination | Loop/Stuck | Plan Drift | State Explosion | Infinite Refinement |
| **Observability** | Low | High (Step-wise) | High (Plan-based) | Very High | High |
| **Enterprise Readiness** | High (Simple) | High (Standard) | Very High (Predictable) | Low (Costly) | Medium |
| **Composition** | Sequential | Sequential | Hierarchical | Recursive | Iterative |

## 3. Detailed Scaling Analysis

### 3.1 Token Growth and Cost Analysis
- **Linear Strategies (CoT, ReAct):** Token consumption grows linearly with the number of steps. For a typical enterprise workload (e.g., customer support), d=5-10, leading to ~2k-5k tokens.
- **Search Strategies (ToT):** Token consumption grows exponentially. With a branching factor b=3 and depth d=3, the cost is ~27x the base reasoning cost. This is often prohibitive for real-time applications.
- **Cost Predictability:** Plan-and-Execute offers the best cost predictability as the plan size is determined early. ToT is the least predictable without aggressive pruning.

### 3.2 Latency Amplification
- **Sequential Bottlenecks:** All strategies suffer from the sequential nature of LLM token generation.
- **Tool Overhead:** ReAct and Plan-and-Execute are heavily influenced by tool latency. In enterprise environments, tool I/O (e.g., DB queries) often exceeds inference time.
- **Parallelization:** Plan-and-Execute allows for parallel execution of independent sub-tasks, significantly reducing wall-clock time compared to ReAct.

### 3.3 Memory and Context Scaling
- **Context Window Pressure:** Iterative strategies (ReAct, Reflexion) accumulate history, leading to O(d^2) token growth if the entire history is re-sent in every prompt.
- **State Management:** Enterprise-grade implementations must use external state stores to manage memory beyond the context window.

## 4. Failure Scenarios and Production Use Cases

### 4.1 Chain-of-Thought (CoT)
- **Failure Scenario:** "Reasoning Drift" where a small error in an early step propagates and magnifies.
- **Production Use Case:** Simple classification or extraction tasks where logic is straightforward.

### 4.2 ReAct
- **Failure Scenario:** "Tool Loop" where the agent repeatedly calls the same tool with the same parameters because the response didn't meet its implicit expectation.
- **Production Use Case:** Dynamic information retrieval where the next step depends on external data (e.g., technical support).

### 4.3 Plan-and-Execute
- **Failure Scenario:** "Stale Plan" where the environment changes during execution, making the remaining pre-planned steps invalid.
- **Production Use Case:** Complex workflows with known sub-tasks (e.g., automated onboarding).

### 4.4 Tree-of-Thoughts (ToT)
- **Failure Scenario:** "Combinatorial Explosion" where the search space becomes too large to explore within timeout/budget constraints.
- **Production Use Case:** High-stakes creative problem solving or complex code optimization.

### 4.5 Reflexion
- **Failure Scenario:** "Echo Chamber" where the agent critiques its own work but fails to identify fundamental flaws, leading to polished but incorrect output.
- **Production Use Case:** Content generation or code writing where quality is paramount.

## 5. Enterprise Deployment Guidance

### 5.1 Cost Predictability
- Implement **Token Quotas** at the strategy level.
- Use **Plan-and-Execute** for budget-sensitive applications.

### 5.2 Reliability and Constraints
- **Timeouts:** Implement hard timeouts for search-based methods.
- **Max Iterations:** Always cap ReAct and Reflexion loops.

### 5.3 Security and Isolation
- **Tool Sandbox:** All tool executions must be sandboxed.
- **Data Masking:** Ensure PII is masked before being sent to the LLM in reasoning steps.

### 5.4 Explainability and Auditability
- **Traceability:** Use the planning topology to generate audit logs. Plan-and-Execute provides a natural "Work Breakdown Structure" for auditors.
"""

    with open(f"{base_path}/scaling_report.md", "w") as f:
        f.write(scaling_report)

if __name__ == "__main__":
    generate_artifacts()
