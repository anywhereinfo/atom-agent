| Strategy | Topology | Control Model | Complexity | Cost/Latency | Readiness |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Chain of Thought (CoT) | Linear | Predictive / Open-loop | `O(d)` | Linear token growth: T_total = T_prompt + d * T_step | Production Ready (High) |
| ReAct (Reason + Act) | Iterative / State Machine | Reactive / Closed-loop | `O(d * (t + r))` | High token growth due to repeated context updates | Production Ready (Moderate) |
| Plan-and-Execute | Hierarchical / Two-Stage | Predictive (Plan) + Reactive (Execute) | `O(P + E)` | Bimodal: Large planning burst followed by sequential execution | Production Ready (High) |
| Tree of Thoughts (ToT) | Tree Search | Predictive / Closed-loop (Search) | `O(b^d)` | Exponential token growth | Experimental (Low) |
| Multi-Agent Coordination | Graph / Mesh | Distributed / Decentralized | `O(N * d)` | Variable; depends on communication frequency and agent count | Production Ready (Moderate/Emerging) |
