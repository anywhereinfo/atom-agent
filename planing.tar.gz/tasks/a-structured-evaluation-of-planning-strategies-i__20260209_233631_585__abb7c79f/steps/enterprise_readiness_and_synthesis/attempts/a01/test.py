import os
import pytest

def test_artifacts_exist():
    artifacts_dir = "steps/enterprise_readiness_and_synthesis/attempts/a01/artifacts"
    assert os.path.exists(os.path.join(artifacts_dir, "final_evaluation_report.md"))
    assert os.path.exists(os.path.join(artifacts_dir, "comparative_matrix.md"))

def test_report_content():
    artifacts_dir = "steps/enterprise_readiness_and_synthesis/attempts/a01/artifacts"
    with open(os.path.join(artifacts_dir, "final_evaluation_report.md"), "r") as f:
        content = f.read()
    
    # Check for mandatory sections
    assert "Architectural Comparison Matrix" in content
    assert "Detailed Strategy Analysis" in content
    assert "Enterprise Deployment Guidance" in content
    assert "Synthesis & Trade-offs" in content
    
    # Check for mandatory dimensions in strategy analysis
    dimensions = [
        "Topology", "Control Model", "Computational Complexity", 
        "Cost & Scaling", "Failure Modes", "Failure Scenario", "Determinism Spectrum", 
        "Observability & Governance", "Composition Patterns", "Production Readiness"
    ]
    for dim in dimensions:
        assert dim in content

    # Check for formal complexity notation
    assert "`O(d)`" in content
    assert "`O(b^d)`" in content
    assert "`O(P + E)`" in content

    # Check for real-world use cases
    assert "Real-World Production Use Case" in content
    assert "customer support ticket" in content
    assert "market research assistants" in content
    assert "drug discovery" in content

    # Check for deployment guidance dimensions
    assert "Cost Predictability" in content
    assert "Reliability & Security" in content
    assert "Explainability & Auditability" in content

def test_matrix_content():
    artifacts_dir = "steps/enterprise_readiness_and_synthesis/attempts/a01/artifacts"
    with open(os.path.join(artifacts_dir, "comparative_matrix.md"), "r") as f:
        content = f.read()
    
    assert "| Strategy | Topology | Control Model | Complexity | Cost/Latency | Readiness |" in content
    assert "Chain of Thought" in content
    assert "ReAct" in content
    assert "Tree of Thoughts" in content
    assert "Plan-and-Execute" in content
