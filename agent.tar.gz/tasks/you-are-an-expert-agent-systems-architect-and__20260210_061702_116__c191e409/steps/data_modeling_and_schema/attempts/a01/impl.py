from typing import List, Dict, Any, Optional, Union, Literal
from pydantic import BaseModel, Field
from datetime import datetime

# --- Basic State Components ---

class Message(BaseModel):
    role: str
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)

class PlanStep(BaseModel):
    id: str
    title: str
    description: str
    status: Literal["pending", "in_progress", "completed", "failed"] = "pending"
    dependencies: List[str] = []

class Plan(BaseModel):
    steps: List[PlanStep]
    current_step_id: Optional[str] = None

class ResearchNote(BaseModel):
    source: str
    content: str
    tags: List[str] = []

class Command(BaseModel):
    tool: str
    arguments: Dict[str, Any]
    status: Literal["queued", "running", "success", "error"] = "queued"

class AuditEntry(BaseModel):
    timestamp: datetime = Field(default_factory=datetime.now)
    event_type: str
    details: Dict[str, Any]

# --- Memory Subsystem ---

class WorkingMemory(BaseModel):
    current_focus: str
    active_variables: Dict[str, Any] = {}

class EpisodicMemory(BaseModel):
    trajectories: List[Dict[str, Any]] = [] # Past execution paths

class SemanticMemory(BaseModel):
    knowledge_base: Dict[str, Any] = {} # Facts/Concepts

class ProceduralMemory(BaseModel):
    skills: List[str] = [] # IDs of available skills

class PolicyMemory(BaseModel):
    constraints: List[str] = []
    preferences: Dict[str, Any] = {}

class MemorySystem(BaseModel):
    working: WorkingMemory
    episodic: EpisodicMemory
    semantic: SemanticMemory
    procedural: ProceduralMemory
    policy: PolicyMemory

# --- Skill Definition ---

class SkillMetadata(BaseModel):
    name: str
    description: str
    version: str
    author: Optional[str] = None

class Skill(BaseModel):
    metadata: SkillMetadata
    code: str
    tests: str
    version: str # Redundant but requested in criteria

class SkillProposal(BaseModel):
    proposed_skill: Skill
    rationale: str

# --- Evaluation Data (Systems-Level) ---

class EvaluationApproach(BaseModel):
    name: str
    planning_topology: str # e.g., Linear, Hierarchical, DAG
    control_model: str # e.g., Centralized, Decentralized, Blackboard
    computational_complexity: str # e.g., O(n), O(b^d)
    failure_modes: List[str]
    determinism_class: str # e.g., Deterministic, Stochastic, Quasi-deterministic
    observability_governance: str
    enterprise_suitability: str
    composition_patterns: List[str]
    failure_scenario: str
    production_use_case: str

# --- Main Agent State ---

class AgentState(BaseModel):
    messages: List[Message]
    plan: Plan
    research_notes: List[ResearchNote]
    skill_proposal: Optional[SkillProposal] = None
    command_queue: List[Command]
    audit_log: List[AuditEntry]
    memory: MemorySystem
    evaluations: List[EvaluationApproach] = []
