import pytest
from datetime import datetime
from steps.data_modeling_and_schema.attempts.a01.impl import (
    AgentState, Plan, PlanStep, Message, ResearchNote, Command, AuditEntry,
    MemorySystem, WorkingMemory, EpisodicMemory, SemanticMemory, ProceduralMemory, PolicyMemory,
    Skill, SkillMetadata, SkillProposal, EvaluationApproach
)

def test_agent_state_instantiation():
    state = AgentState(
        messages=[Message(role="user", content="hello")],
        plan=Plan(steps=[PlanStep(id="1", title="Init", description="Initialize project")]),
        research_notes=[ResearchNote(source="web", content="found something")],
        command_queue=[Command(tool="search", arguments={"q": "test"})],
        audit_log=[AuditEntry(event_type="init", details={})],
        memory=MemorySystem(
            working=WorkingMemory(current_focus="testing"),
            episodic=EpisodicMemory(),
            semantic=SemanticMemory(),
            procedural=ProceduralMemory(),
            policy=PolicyMemory()
        )
    )
    assert len(state.messages) == 1
    assert state.plan.steps[0].id == "1"
    assert state.memory.working.current_focus == "testing"

def test_skill_schema():
    skill = Skill(
        metadata=SkillMetadata(name="test_skill", description="a test skill", version="1.0.0"),
        code="def test(): pass",
        tests="def test_test(): assert True",
        version="1.0.0"
    )
    assert skill.metadata.name == "test_skill"
    assert skill.version == "1.0.0"

def test_evaluation_approach_schema():
    eval_data = EvaluationApproach(
        name="Chain of Thought",
        planning_topology="Linear",
        control_model="Centralized",
        computational_complexity="O(n)",
        failure_modes=["Hallucination", "Looping"],
        determinism_class="Stochastic",
        observability_governance="High transparency via trace",
        enterprise_suitability="Good for reasoning, slow for prod",
        composition_patterns=["Sequential"],
        failure_scenario="Model gets stuck in a repetitive loop when faced with ambiguous input.",
        production_use_case="Customer support chatbot explaining complex billing issues."
    )
    
    assert eval_data.planning_topology == "Linear"
    assert eval_data.failure_scenario != ""
    assert eval_data.production_use_case != ""

def test_state_includes_required_fields():
    # Acceptance criteria: messages, plan, research_notes, skill_proposal, command_queue, audit_log
    fields = AgentState.__fields__
    required = ['messages', 'plan', 'research_notes', 'skill_proposal', 'command_queue', 'audit_log']
    for field in required:
        assert field in fields

def test_memory_subsystem_types():
    # Acceptance criteria: Working, Episodic, Semantic, Procedural, Policy
    fields = MemorySystem.__fields__
    required = ['working', 'episodic', 'semantic', 'procedural', 'policy']
    for field in required:
        assert field in fields
