import os
import pytest

def test_artifacts_exist():
    artifacts_dir = "steps/research_and_architecture_synthesis/attempts/a01/artifacts"
    assert os.path.exists(os.path.join(artifacts_dir, "research_notes.md"))
    assert os.path.exists(os.path.join(artifacts_dir, "system_overview.md"))
    assert os.path.exists(os.path.join(artifacts_dir, "threat_model.md"))

def test_research_notes_content():
    path = "steps/research_and_architecture_synthesis/attempts/a01/artifacts/research_notes.md"
    with open(path, "r") as f:
        content = f.read()
    assert "STORM" in content
    assert "Voyager" in content
    assert "Sandboxing" in content
    # Check for at least 3 references
    assert content.count("Reference") >= 3 or content.count("arXiv") >= 2

def test_system_overview_content():
    path = "steps/research_and_architecture_synthesis/attempts/a01/artifacts/system_overview.md"
    with open(path, "r") as f:
        content = f.read()
    assert "Goals" in content
    assert "Non-Goals" in content
    assert "Primary Scenarios" in content
    assert "Planning Topology" in content
    assert "Hierarchical" in content
    assert "Control Model" in content
    assert "Centralized/Predictive" in content

def test_threat_model_content():
    path = "steps/research_and_architecture_synthesis/attempts/a01/artifacts/threat_model.md"
    with open(path, "r") as f:
        content = f.read()
    assert "Prompt Injection" in content
    assert "Remote Code Execution" in content or "RCE" in content
    assert "Data Leakage" in content

def test_analytical_depth():
    path = "steps/research_and_architecture_synthesis/attempts/a01/artifacts/system_overview.md"
    with open(path, "r") as f:
        content = f.read()
    # Check for complexity/cost analysis as per analytical depth floor
    assert "Complexity & Cost Analysis" in content
    assert "O(" in content
