# Research Notes: SOTA Agent Patterns

## 1. STORM (Stanford University)
**Reference:** Shao, Y., et al. (2024). "Assisting in Writing Wikipedia-like Articles From Scratch with Large Language Models." arXiv:2402.14207.
**Key Patterns:**
- **Pre-writing Synthesis:** Focuses on the pre-writing stage to generate long, grounded articles.
- **Multi-perspective Questioning:** Discovers diverse perspectives and simulates conversations between a "writer" and a "topic expert."
- **Outline-driven Retrieval:** Uses an outline to organize information gathered from trusted sources.

## 2. Voyager (NVIDIA)
**Reference:** Wang, G., et al. (2023). "Voyager: An Open-Ended Embodied Agent with Large Language Models." arXiv:2305.16291.
**Key Patterns:**
- **Automatic Curriculum:** Proposes tasks based on the agent's current state and skill level.
- **Skill Library:** Stores successful programs (Javascript/Python) in a vector database for reuse.
- **Iterative Prompting:** Incorporates environment feedback and execution errors to refine code.

## 3. Safe Command Execution (Sandboxing)
**References:** 
- "Firecracker, gVisor, Containers, and WebAssembly – Comparing Isolation Technologies for AI Agents." (SoftwareSeni)
- "Sandboxing Agentic AI Workflows with WebAssembly." (NVIDIA)
**Key Patterns:**
- **MicroVM Isolation:** Using Firecracker or Kata Containers to provide hardware-level isolation for untrusted code.
- **User-space Kernels:** gVisor intercepts syscalls to protect the host kernel.
- **WebAssembly (Wasm):** Provides a lightweight, language-agnostic sandbox for executing logic with restricted capabilities.
