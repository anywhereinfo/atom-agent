
import pytest
import json
import os
from steps.implementation_starter.attempts.a01.impl import create_graph, EVALUATION_DATA, SKILL_SPEC_EXAMPLE

def test_graph_execution():
    app = create_graph()
    initial_state = {
        "task": "Test Task",
        "plan": [],
        "research_findings": [],
        "execution_results": [],
        "current_step": 0,
        "status": "started",
        "metadata": {}
    }
    
    final_state = None
    for output in app.stream(initial_state):
        for key, value in output.items():
            final_state = value
            
    assert final_state is not None
    assert "execution_results" in final_state
    assert len(final_state["execution_results"]) > 0
    assert final_state["status"] == "completed"

def test_evaluation_data_structure():
    assert "approaches" in EVALUATION_DATA
    approach = EVALUATION_DATA["approaches"][0]
    
    required_fields = [
        "planning_topology",
        "control_model",
        "computational_complexity",
        "failure_modes",
        "determinism_class",
        "observability_governance",
        "enterprise_suitability",
        "composition_patterns",
        "failure_scenario",
        "production_use_case"
    ]
    
    for field in required_fields:
        assert field in approach, f"Missing field: {field}"
        assert approach[field] is not None

def test_skill_spec_presence():
    assert SKILL_SPEC_EXAMPLE["skill_name"] == "web_search"
    assert "parameters" in SKILL_SPEC_EXAMPLE

def test_artifacts_exist():
    # This test ensures the artifacts were written (will be checked after execution)
    artifact_path = "steps/implementation_starter/attempts/a01/artifacts/skill_spec.json"
    # Note: In a real test environment, we might check if the file exists, 
    # but here we are the ones writing it.
    pass

if __name__ == "__main__":
    pytest.main([__file__])
