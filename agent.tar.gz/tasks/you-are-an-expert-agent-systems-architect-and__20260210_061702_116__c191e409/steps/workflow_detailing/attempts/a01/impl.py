import json
import os

class WorkflowDetailer:
    def __init__(self, output_dir):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def get_deep_research_workflow(self):
        return {
            "name": "Deep Research",
            "stages": [
                {
                    "stage": "Query Planning",
                    "description": "Decompose complex user queries into atomic research questions.",
                    "controls": ["Query expansion", "Deduplication"]
                },
                {
                    "stage": "Multi-Perspective Retrieval",
                    "description": "Search for information from diverse viewpoints (STORM-inspired).",
                    "controls": ["Source diversity check", "Domain allowlisting"]
                },
                {
                    "stage": "Synthesis & Fact-Checking",
                    "description": "Aggregate findings and verify claims against retrieved snippets.",
                    "controls": ["Cross-referencing", "Hallucination detection LLM-pass"]
                },
                {
                    "stage": "Citation & Formatting",
                    "description": "Generate final report with verifiable citations.",
                    "controls": ["Citation policy enforcement", "Link validation"]
                }
            ],
            "policies": {
                "hallucination_control": "Every claim must be mapped to at least one retrieved snippet. Claims without evidence are discarded.",
                "citation_policy": "Format: [Source Title](URL). All external data must be cited."
            },
            "failure_scenarios": [
                {
                    "scenario": "Conflicting Information",
                    "description": "Two reputable sources provide contradictory facts.",
                    "mitigation": "The agent must highlight the contradiction in the report, citing both sources and providing context on the discrepancy."
                }
            ]
        }

    def get_skill_learning_workflow(self):
        return {
            "name": "Skill Learning",
            "stages": [
                {
                    "stage": "Proposal",
                    "description": "Identify a missing capability and propose a new skill.",
                    "controls": ["Capability gap analysis"]
                },
                {
                    "stage": "Specification & Test Generation",
                    "description": "Define the skill's API and generate unit tests.",
                    "controls": ["Input/Output schema validation"]
                },
                {
                    "stage": "Implementation (Sandbox)",
                    "description": "Generate code and execute it in a restricted environment.",
                    "controls": ["Static analysis (AST)", "Runtime resource limits"]
                },
                {
                    "stage": "Verification & Promotion",
                    "description": "Verify tests pass and promote to the skill registry.",
                    "controls": ["Automated test suite", "Security audit pass"]
                }
            ],
            "promotion_flow": ["proposed", "implemented", "verified", "registry"],
            "failure_scenarios": [
                {
                    "scenario": "Malicious Code Generation",
                    "description": "LLM generates code that attempts to access sensitive files or network.",
                    "mitigation": "Static analysis blocks restricted imports (e.g., 'os', 'subprocess' outside allowlist) and gVisor blocks unauthorized syscalls."
                }
            ]
        }

    def get_command_execution_workflow(self):
        return {
            "name": "Command Execution",
            "stages": [
                {
                    "stage": "Policy Check",
                    "description": "Validate command against allowlist and RBAC.",
                    "controls": ["Command allowlist", "Argument sanitization"]
                },
                {
                    "stage": "Sandbox Provisioning",
                    "description": "Spin up an isolated container (gVisor/Docker).",
                    "controls": ["FS isolation (bind-mounts)", "Network namespacing"]
                },
                {
                    "stage": "Execution & Monitoring",
                    "description": "Run command and monitor for suspicious activity.",
                    "controls": ["Syscall filtering", "Resource quotas (cgroups)"]
                }
            ],
            "sandboxing_tech": "gVisor (runsc) for syscall interception and Docker for containerization.",
            "isolation_policy": "Read-only access to system files; Read-Write access only to the assigned workspace directory.",
            "failure_scenarios": [
                {
                    "scenario": "Sandbox Escape Attempt",
                    "description": "Command tries to exploit kernel vulnerabilities to reach the host.",
                    "mitigation": "gVisor's Sentry intercepts all syscalls, preventing direct host kernel interaction. Detection of 'forbidden' syscalls triggers immediate container termination."
                }
            ]
        }

    def generate_artifacts(self):
        workflows = {
            "deep_research": self.get_deep_research_workflow(),
            "skill_learning": self.get_skill_learning_workflow(),
            "command_execution": self.get_command_execution_workflow()
        }
        
        # Write JSON artifact
        with open(os.path.join(self.output_dir, "workflows.json"), "w") as f:
            json.dump(workflows, f, indent=2)
            
        # Write Markdown artifact
        md_content = "# Detailed Workflows\n\n"
        for key, wf in workflows.items():
            md_content += f"## {wf['name']}\n"
            md_content += "### Stages\n"
            for stage in wf['stages']:
                md_content += f"- **{stage['stage']}**: {stage['description']}\n"
                md_content += f"  - *Controls*: {', '.join(stage['controls'])}\n"
            
            if "policies" in wf:
                md_content += "### Policies\n"
                for p_name, p_desc in wf['policies'].items():
                    md_content += f"- **{p_name.replace('_', ' ').title()}**: {p_desc}\n"
            
            if "promotion_flow" in wf:
                md_content += f"### Promotion Flow\n`{' -> '.join(wf['promotion_flow'])}`\n"
                
            if "sandboxing_tech" in wf:
                md_content += f"### Sandboxing Technology\n{wf['sandboxing_tech']}\n"
                md_content += f"### Isolation Policy\n{wf['isolation_policy']}\n"

            md_content += "### Failure Scenarios\n"
            for fs in wf['failure_scenarios']:
                md_content += f"- **{fs['scenario']}**: {fs['description']}\n"
                md_content += f"  - *Mitigation*: {fs['mitigation']}\n"
            md_content += "\n"

        with open(os.path.join(self.output_dir, "workflows_report.md"), "w") as f:
            f.write(md_content)

        # Analytical dimensions report
        analytical_report = """# Analytical Dimensions: Workflow Design

## Planning Topology Classification
The system uses a **Hierarchical Planning Topology**. 
- The **Strategic Planner** handles the "Deep Research" workflow, decomposing high-level goals.
- The **Skill Manager** handles the "Skill Learning" workflow, providing the atomic capabilities needed by the planner.
- The **Executor** handles the "Command Execution" workflow, ensuring safe interaction with the environment.

## Control Model
The control model is **Centralized/Predictive** with **Reactive Guardrails**.
- The central agent predicts the next best action.
- Sandboxes and policy checkers provide reactive safety (blocking/terminating) when predictions lead to unsafe states.

## Computational Complexity & Cost
- **Deep Research**: O(P * S) where P is the number of perspectives and S is the number of search results per perspective. Cost is dominated by LLM synthesis calls.
- **Skill Learning**: O(I) where I is the number of iterations to pass tests. Cost includes multiple LLM generation and verification cycles.
- **Command Execution**: O(1) overhead for sandboxing. Latency is slightly increased due to gVisor syscall interception (~10-20%).

## Determinism Spectrum
- **Deep Research**: Stochastic (LLM-based synthesis).
- **Skill Learning**: Semi-deterministic (Tests provide a deterministic success/fail signal, but implementation generation is stochastic).
- **Command Execution**: Deterministic (Policy and sandbox rules are fixed).

## Failure Modes & Mitigations
| Workflow | Failure Mode | Mitigation |
| --- | --- | --- |
| Research | Hallucination | Cross-referencing & Citation Enforcement |
| Skill | Malicious Code | Static Analysis & Runtime Sandboxing |
| Execution | Sandbox Escape | gVisor Syscall Interception |

## Observability & Governance
- All LLM prompts and responses are logged.
- Sandbox execution logs (stdout/stderr) are captured and audited.
- Skill registry requires a cryptographic hash for each approved skill to prevent tampering.

## Enterprise Production Readiness
- **Security**: gVisor provides industry-standard isolation.
- **Scalability**: Stateless execution allows for horizontal scaling of sandboxes.
- **Auditability**: Full trace of research sources and execution commands.
"""
        with open(os.path.join(self.output_dir, "analytical_dimensions.md"), "w") as f:
            f.write(analytical_report)

if __name__ == "__main__":
    import sys
    # Use the path from the environment or default to the staging target
    output_path = "steps/workflow_detailing/attempts/a01/artifacts"
    detailer = WorkflowDetailer(output_path)
    detailer.generate_artifacts()
