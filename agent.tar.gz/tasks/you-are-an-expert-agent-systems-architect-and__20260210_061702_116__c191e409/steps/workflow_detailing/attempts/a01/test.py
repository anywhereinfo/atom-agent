import os
import json
import pytest

# Paths
ARTIFACTS_DIR = "steps/workflow_detailing/attempts/a01/artifacts"
WORKFLOWS_JSON = os.path.join(ARTIFACTS_DIR, "workflows.json")
WORKFLOWS_REPORT = os.path.join(ARTIFACTS_DIR, "workflows_report.md")
ANALYTICAL_REPORT = os.path.join(ARTIFACTS_DIR, "analytical_dimensions.md")

def test_artifacts_exist():
    assert os.path.exists(WORKFLOWS_JSON)
    assert os.path.exists(WORKFLOWS_REPORT)
    assert os.path.exists(ANALYTICAL_REPORT)

def test_deep_research_workflow():
    with open(WORKFLOWS_JSON, "r") as f:
        data = json.load(f)
    
    dr = data.get("deep_research")
    assert dr is not None
    assert "hallucination_control" in dr["policies"]
    assert "citation_policy" in dr["policies"]
    
    # Check for failure scenario
    scenarios = [s["scenario"] for s in dr["failure_scenarios"]]
    assert any("Conflict" in s for s in scenarios)

def test_skill_learning_workflow():
    with open(WORKFLOWS_JSON, "r") as f:
        data = json.load(f)
    
    sl = data.get("skill_learning")
    assert sl is not None
    assert "promotion_flow" in sl
    assert "registry" in sl["promotion_flow"]
    assert "proposed" in sl["promotion_flow"]
    
    # Check for failure scenario
    scenarios = [s["scenario"] for s in sl["failure_scenarios"]]
    assert any("Malicious" in s for s in scenarios)

def test_command_execution_workflow():
    with open(WORKFLOWS_JSON, "r") as f:
        data = json.load(f)
    
    ce = data.get("command_execution")
    assert ce is not None
    assert "gVisor" in ce["sandboxing_tech"]
    assert "Docker" in ce["sandboxing_tech"]
    assert "isolation_policy" in ce
    
    # Check for failure scenario
    scenarios = [s["scenario"] for s in ce["failure_scenarios"]]
    assert any("Escape" in s for s in scenarios)

def test_analytical_dimensions():
    with open(ANALYTICAL_REPORT, "r") as f:
        content = f.read()
    
    required_sections = [
        "Planning Topology Classification",
        "Control Model",
        "Computational Complexity & Cost",
        "Determinism Spectrum",
        "Failure Modes & Mitigations",
        "Observability & Governance",
        "Enterprise Production Readiness"
    ]
    for section in required_sections:
        assert section in content

def test_complexity_notation():
    with open(ANALYTICAL_REPORT, "r") as f:
        content = f.read()
    # Check for Big O notation
    assert "O(" in content

if __name__ == "__main__":
    pytest.main([__file__])
