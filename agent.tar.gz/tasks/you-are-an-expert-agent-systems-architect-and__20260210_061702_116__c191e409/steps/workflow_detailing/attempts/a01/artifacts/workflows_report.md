# Detailed Workflows

## Deep Research
### Stages
- **Query Planning**: Decompose complex user queries into atomic research questions.
  - *Controls*: Query expansion, Deduplication
- **Multi-Perspective Retrieval**: Search for information from diverse viewpoints (STORM-inspired).
  - *Controls*: Source diversity check, Domain allowlisting
- **Synthesis & Fact-Checking**: Aggregate findings and verify claims against retrieved snippets.
  - *Controls*: Cross-referencing, Hallucination detection LLM-pass
- **Citation & Formatting**: Generate final report with verifiable citations.
  - *Controls*: Citation policy enforcement, Link validation
### Policies
- **Hallucination Control**: Every claim must be mapped to at least one retrieved snippet. Claims without evidence are discarded.
- **Citation Policy**: Format: [Source Title](URL). All external data must be cited.
### Failure Scenarios
- **Conflicting Information**: Two reputable sources provide contradictory facts.
  - *Mitigation*: The agent must highlight the contradiction in the report, citing both sources and providing context on the discrepancy.

## Skill Learning
### Stages
- **Proposal**: Identify a missing capability and propose a new skill.
  - *Controls*: Capability gap analysis
- **Specification & Test Generation**: Define the skill's API and generate unit tests.
  - *Controls*: Input/Output schema validation
- **Implementation (Sandbox)**: Generate code and execute it in a restricted environment.
  - *Controls*: Static analysis (AST), Runtime resource limits
- **Verification & Promotion**: Verify tests pass and promote to the skill registry.
  - *Controls*: Automated test suite, Security audit pass
### Promotion Flow
`proposed -> implemented -> verified -> registry`
### Failure Scenarios
- **Malicious Code Generation**: LLM generates code that attempts to access sensitive files or network.
  - *Mitigation*: Static analysis blocks restricted imports (e.g., 'os', 'subprocess' outside allowlist) and gVisor blocks unauthorized syscalls.

## Command Execution
### Stages
- **Policy Check**: Validate command against allowlist and RBAC.
  - *Controls*: Command allowlist, Argument sanitization
- **Sandbox Provisioning**: Spin up an isolated container (gVisor/Docker).
  - *Controls*: FS isolation (bind-mounts), Network namespacing
- **Execution & Monitoring**: Run command and monitor for suspicious activity.
  - *Controls*: Syscall filtering, Resource quotas (cgroups)
### Sandboxing Technology
gVisor (runsc) for syscall interception and Docker for containerization.
### Isolation Policy
Read-only access to system files; Read-Write access only to the assigned workspace directory.
### Failure Scenarios
- **Sandbox Escape Attempt**: Command tries to exploit kernel vulnerabilities to reach the host.
  - *Mitigation*: gVisor's Sentry intercepts all syscalls, preventing direct host kernel interaction. Detection of 'forbidden' syscalls triggers immediate container termination.

