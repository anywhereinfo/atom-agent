
import pytest
import json
import os
from steps.langgraph_topology_design.attempts.a01.impl import LangGraphTopology

def test_nodes_exist():
    topology = LangGraphTopology()
    required_nodes = ["Planner", "Researcher", "SkillLearner", "Executor", "Reflector", "Gatekeeper"]
    for node in required_nodes:
        assert node in topology.nodes
        assert "responsibility" in topology.nodes[node]
        assert "inputs" in topology.nodes[node]
        assert "outputs" in topology.nodes[node]

def test_mermaid_diagram():
    topology = LangGraphTopology()
    diagram = topology.get_mermaid_diagram()
    assert "graph TD" in diagram
    assert "Planner" in diagram
    assert "Executor" in diagram
    assert "Reflector" in diagram

def test_complexity_analysis():
    topology = LangGraphTopology()
    analysis = topology.get_complexity_analysis()
    assert analysis["complexity"] == "O(b^d)"
    assert "b" in analysis["parameters"]
    assert "d" in analysis["parameters"]

def test_failure_scenarios():
    topology = LangGraphTopology()
    scenarios = topology.get_failure_scenarios()
    assert len(scenarios) >= 3
    for scenario in scenarios:
        assert "node" in scenario
        assert "failure" in scenario
        assert "mitigation" in scenario

def test_artifacts_exist():
    base_path = "steps/langgraph_topology_design/attempts/a01/artifacts"
    assert os.path.exists(f"{base_path}/topology_design.json")
    assert os.path.exists(f"{base_path}/topology_report.md")

def test_report_content():
    base_path = "steps/langgraph_topology_design/attempts/a01/artifacts"
    with open(f"{base_path}/topology_report.md", "r") as f:
        content = f.read()
    assert "# LangGraph Topology Design Report" in content
    assert "## 4. Complexity Analysis" in content
    assert "O(b^d)" in content
