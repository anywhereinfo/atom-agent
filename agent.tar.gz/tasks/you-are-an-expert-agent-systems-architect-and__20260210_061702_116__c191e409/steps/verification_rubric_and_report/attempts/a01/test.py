import os
import json
import pytest

def test_artifacts_exist():
    artifacts_dir = "steps/verification_rubric_and_report/attempts/a01/artifacts"
    assert os.path.exists(os.path.join(artifacts_dir, "verification_report.md"))
    assert os.path.exists(os.path.join(artifacts_dir, "rubric.json"))

def test_rubric_scores():
    artifacts_dir = "steps/verification_rubric_and_report/attempts/a01/artifacts"
    with open(os.path.join(artifacts_dir, "rubric.json"), "r") as f:
        rubric = json.load(f)
    
    # Check weights sum to 1.0 (approx)
    total_weight = sum(item["weight"] for item in rubric.values())
    assert abs(total_weight - 1.0) < 1e-9
    
    # Check Safety >= 4
    assert rubric["Safety"]["score"] >= 4
    
    # Check Testability >= 4
    assert rubric["Testability"]["score"] >= 4
    
    # Check Overall Score >= 85
    total_score = sum(item["score"] * item["weight"] for item in rubric.values()) * 20
    assert total_score >= 85

def test_report_content():
    artifacts_dir = "steps/verification_rubric_and_report/attempts/a01/artifacts"
    with open(os.path.join(artifacts_dir, "verification_report.md"), "r") as f:
        content = f.read()
    
    # Assert required sections
    assert "Architectural Comparison Matrix" in content
    assert "Complexity and Cost Analysis" in content
    assert "Enterprise Deployment Guidance" in content
    assert "Remediation Plans" in content
    
    # Assert specific dimensions in matrix
    assert "Planning Topology" in content
    assert "Control Model" in content
    assert "Computational Complexity" in content
    assert "Failure Modes" in content
    assert "Determinism Spectrum" in content
    assert "Observability/Governance" in content
    assert "Enterprise Readiness" in content
    assert "Composition Patterns" in content
    
    # Assert formal notation
    assert "$O(P \\times S)$" in content or "O(P * S)" in content
    assert "$O(I)$" in content or "O(I)" in content

if __name__ == "__main__":
    pytest.main([__file__])
