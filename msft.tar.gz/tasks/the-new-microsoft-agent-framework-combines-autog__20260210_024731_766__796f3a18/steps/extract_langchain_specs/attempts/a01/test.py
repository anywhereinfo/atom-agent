import json
import os

def test_langchain_specs_exists():
    path = "steps/extract_langchain_specs/attempts/a01/artifacts/langchain_specs.json"
    assert os.path.exists(path), f"Artifact not found at {path}"

def test_langchain_specs_fields():
    path = "steps/extract_langchain_specs/attempts/a01/artifacts/langchain_specs.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    assert "architecture_type" in data
    assert "state_management" in data
    assert "persistence_model" in data
    
    # Analytical depth checks
    assert "analytical_dimensions" in data
    dims = data["analytical_dimensions"]
    assert "planning_topology" in dims
    assert "control_model" in dims
    assert "computational_complexity" in dims
    assert "failure_modes" in dims
    assert "determinism_spectrum" in dims
    assert "production_readiness" in dims
    
    # Check for at least one failure scenario and production use case
    assert len(dims["failure_modes"]) >= 1
    assert "production_use_case" in data

def test_json_validity():
    path = "steps/extract_langchain_specs/attempts/a01/artifacts/langchain_specs.json"
    with open(path, "r") as f:
        try:
            json.load(f)
        except json.JSONDecodeError:
            assert False, "langchain_specs.json is not a valid JSON"
