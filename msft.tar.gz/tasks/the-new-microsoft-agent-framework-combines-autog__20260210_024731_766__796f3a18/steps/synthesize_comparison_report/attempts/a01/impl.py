import json
import os

def load_artifacts():
    deps = [
        "compare_architectural_patterns",
        "compare_orchestration_mechanisms",
        "compare_ecosystem_and_tooling",
        "compare_operational_readiness"
    ]
    artifacts = {}
    for dep in deps:
        path = f"steps/{dep}/committed/artifacts"
        if os.path.exists(path):
            files = os.listdir(path)
            for f in files:
                if f.endswith(".json") and f != "test_results.json":
                    with open(os.path.join(path, f), 'r') as file:
                        artifacts[f] = json.load(file)
    return artifacts

def generate_report(artifacts):
    arch = artifacts.get("architecture_comparison.json", {}).get("frameworks", {})
    eco = artifacts.get("ecosystem_comparison.json", {}).get("frameworks", {})
    orch = artifacts.get("orchestration_comparison.json", {}).get("frameworks", {})
    readiness = artifacts.get("readiness_comparison.json", {})

    # Frameworks list
    frameworks = sorted(list(set(list(arch.keys()) + list(eco.keys()) + list(orch.keys()))))
    
    # Mapping names to be consistent
    name_map = {
        "Microsoft AutoGen": "Microsoft Agent Framework (AutoGen)",
        "AutoGen (AG2)": "Microsoft Agent Framework (AutoGen)",
        "MAF": "Microsoft Agent Framework (AutoGen)",
        "LangGraph": "LangChain / LangGraph",
        "CrewAI": "CrewAI",
        "PydanticAI": "PydanticAI"
    }
    
    # Normalize data
    normalized = {}
    for f in frameworks:
        norm_name = name_map.get(f, f)
        if norm_name not in normalized:
            normalized[norm_name] = {}
        
        # Merge data from different artifacts
        if f in arch: normalized[norm_name].update(arch[f])
        if f in eco: normalized[norm_name].update(eco[f])
        if f in orch: normalized[norm_name].update(orch[f])
        
    report = "# Framework Comparison Report: MAF vs. LangGraph vs. CrewAI vs. PydanticAI\n\n"
    
    report += "## 1. Executive Summary Matrix\n\n"
    report += "| Feature | Microsoft Agent Framework | LangGraph | CrewAI | PydanticAI |\n"
    report += "| :--- | :--- | :--- | :--- | :--- |\n"
    report += f"| **Core Paradigm** | {normalized.get('Microsoft Agent Framework (AutoGen)', {}).get('paradigm', 'Actor / Conversational')} | {normalized.get('LangChain / LangGraph', {}).get('paradigm', 'State Graph')} | {normalized.get('CrewAI', {}).get('paradigm', 'Role-based')} | {normalized.get('PydanticAI', {}).get('paradigm', 'Functional / Typed')} |\n"
    report += f"| **Control Model** | {normalized.get('Microsoft Agent Framework (AutoGen)', {}).get('control_model', 'Decentralized')} | {normalized.get('LangChain / LangGraph', {}).get('control_model', 'Explicit State Machine')} | {normalized.get('CrewAI', {}).get('control_model', 'Manager-led')} | {normalized.get('PydanticAI', {}).get('control_model', 'Dependency Injection')} |\n"
    report += f"| **Determinism** | Low | High | Medium | High |\n"
    report += f"| **Best For** | R&D, Complex Reasoning | Controllable Workflows | Business Processes | Type-safe Data Extraction |\n\n"

    report += "## 2. Architectural Comparison Matrix\n\n"
    report += "| Dimension | Microsoft Agent Framework | LangGraph | CrewAI | PydanticAI |\n"
    report += "| :--- | :--- | :--- | :--- | :--- |\n"
    
    dimensions = [
        ("Planning Topology", "planning_topology", "topology"),
        ("Control Model", "control_model"),
        ("Computational Complexity", "computational_complexity"),
        ("Failure Modes", "failure_modes"),
        ("Determinism Spectrum", "determinism_spectrum", "determinism"),
        ("Observability/Governance", "observability_governance", "observability"),
        ("Enterprise Readiness", "enterprise_readiness", "production_readiness"),
        ("Composition Patterns", "composition_patterns")
    ]
    
    for label, *keys in dimensions:
        row = f"| **{label}** "
        for f in ["Microsoft Agent Framework (AutoGen)", "LangChain / LangGraph", "CrewAI", "PydanticAI"]:
            val = "N/A"
            for k in keys:
                if k in normalized.get(f, {}):
                    val = normalized[f][k]
                    break
            if isinstance(val, list):
                val = ", ".join(val)
            row += f"| {val} "
        report += row + "|\n"
    
    report += "\n## 3. Complexity & Cost Analysis\n\n"
    for f in ["Microsoft Agent Framework (AutoGen)", "LangChain / LangGraph", "CrewAI", "PydanticAI"]:
        report += f"### {f}\n"
        analysis = normalized.get(f, {}).get("cost_complexity_analysis", {})
        if analysis:
            report += f"- **Formal Notation**: `{analysis.get('formal_notation', 'N/A')}`\n"
            report += f"- **Token Growth**: {analysis.get('token_growth', 'N/A')}\n"
            report += f"- **Branching Behavior**: {analysis.get('branching_behavior', 'N/A')}\n"
            report += f"- **Latency Amplification**: {analysis.get('latency_amplification', 'N/A')}\n"
            report += f"- **Tool Overhead**: {analysis.get('tool_overhead', 'N/A')}\n"
            report += f"- **Memory Scaling**: {analysis.get('memory_scaling', 'N/A')}\n"
        else:
            report += "Detailed complexity analysis not available for this framework.\n"
        report += "\n"

    report += "## 4. Enterprise Deployment & Readiness Guide\n\n"
    for f in ["Microsoft Agent Framework (AutoGen)", "LangChain / LangGraph", "CrewAI", "PydanticAI"]:
        report += f"### {f}\n"
        deploy = normalized.get(f, {}).get("enterprise_deployment", {})
        if deploy:
            report += f"- **Cost Predictability**: {deploy.get('cost_predictability', 'N/A')}\n"
            report += f"- **Reliability Constraints**: {deploy.get('reliability_constraints', 'N/A')}\n"
            report += f"- **Security & Isolation**: {deploy.get('security_isolation', 'N/A')}\n"
            report += f"- **Explainability & Auditability**: {deploy.get('explainability_auditability', 'N/A')}\n"
        else:
            report += "Enterprise deployment guidance not available for this framework.\n"
        
        scenario = normalized.get(f, {}).get("failure_scenario", "N/A")
        report += f"- **Typical Failure Scenario**: {scenario}\n"
        
        use_case = normalized.get(f, {}).get("production_use_case", "N/A")
        report += f"- **Production Use Case**: {use_case}\n"
        report += "\n"

    report += "## 5. Decision Guide: When to Choose Which?\n\n"
    report += "### Choose **Microsoft Agent Framework (AutoGen)** when:\n"
    report += "- You need high-autonomy agents that can collaborate and self-correct.\n"
    report += "- The task requires complex, multi-turn reasoning and code execution.\n"
    report += "- You are deeply integrated into the Azure ecosystem.\n\n"
    
    report += "### Choose **LangGraph** when:\n"
    report += "- You need strict control over the agentic workflow and state transitions.\n"
    report += "- Human-in-the-loop and persistence (checkpointing) are critical requirements.\n"
    report += "- You want deep observability via LangSmith.\n\n"
    
    report += "### Choose **CrewAI** when:\n"
    report += "- You are automating structured business processes with clear roles (e.g., Researcher, Writer).\n"
    report += "- You prefer a task-oriented orchestration model over a state-oriented one.\n"
    report += "- You need a framework that is easy to set up for multi-agent collaboration on linear tasks.\n\n"
    
    report += "### Choose **PydanticAI** when:\n"
    report += "- Type safety and developer experience (FastAPI-style) are top priorities.\n"
    report += "- You are building production-grade data extraction or structured API tools.\n"
    report += "- You want minimal framework overhead and native MCP support.\n"

    return report

if __name__ == "__main__":
    artifacts = load_artifacts()
    report_md = generate_report(artifacts)
    
    output_dir = "steps/synthesize_comparison_report/attempts/a01/artifacts"
    os.makedirs(output_dir, exist_ok=True)
    
    with open(os.path.join(output_dir, "framework_comparison_report.md"), "w") as f:
        f.write(report_md)
    
    print("Report generated successfully.")
