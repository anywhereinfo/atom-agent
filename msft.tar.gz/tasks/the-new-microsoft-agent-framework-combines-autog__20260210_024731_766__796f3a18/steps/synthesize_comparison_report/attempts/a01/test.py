import os
import pytest

def test_report_exists():
    report_path = "steps/synthesize_comparison_report/attempts/a01/artifacts/framework_comparison_report.md"
    assert os.path.exists(report_path)

def test_report_sections():
    report_path = "steps/synthesize_comparison_report/attempts/a01/artifacts/framework_comparison_report.md"
    with open(report_path, "r") as f:
        content = f.read()
    
    assert "## 1. Executive Summary Matrix" in content
    assert "## 2. Architectural Comparison Matrix" in content
    assert "## 3. Complexity & Cost Analysis" in content
    assert "## 4. Enterprise Deployment & Readiness Guide" in content
    assert "## 5. Decision Guide" in content

def test_architectural_matrix_dimensions():
    report_path = "steps/synthesize_comparison_report/attempts/a01/artifacts/framework_comparison_report.md"
    with open(report_path, "r") as f:
        content = f.read()
    
    required_dimensions = [
        "Planning Topology",
        "Control Model",
        "Computational Complexity",
        "Failure Modes",
        "Determinism Spectrum",
        "Observability/Governance",
        "Enterprise Readiness",
        "Composition Patterns"
    ]
    
    for dim in required_dimensions:
        assert dim in content

def test_complexity_and_cost_analysis():
    report_path = "steps/synthesize_comparison_report/attempts/a01/artifacts/framework_comparison_report.md"
    with open(report_path, "r") as f:
        content = f.read()
    
    assert "**Formal Notation**" in content
    assert "**Token Growth**" in content
    assert "**Branching Behavior**" in content
    assert "**Latency Amplification**" in content
    assert "**Tool Overhead**" in content
    assert "**Memory Scaling**" in content

def test_enterprise_deployment_guidance():
    report_path = "steps/synthesize_comparison_report/attempts/a01/artifacts/framework_comparison_report.md"
    with open(report_path, "r") as f:
        content = f.read()
    
    assert "**Cost Predictability**" in content
    assert "**Reliability Constraints**" in content
    assert "**Security & Isolation**" in content
    assert "**Explainability & Auditability**" in content
    assert "**Typical Failure Scenario**" in content
    assert "**Production Use Case**" in content
