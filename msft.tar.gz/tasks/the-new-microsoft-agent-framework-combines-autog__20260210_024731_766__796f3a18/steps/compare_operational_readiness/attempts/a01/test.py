import json
import os
import pytest

def test_readiness_comparison_exists():
    path = "steps/compare_operational_readiness/attempts/a01/artifacts/readiness_comparison.json"
    assert os.path.exists(path), f"Artifact {path} does not exist"

def test_readiness_comparison_structure():
    path = "steps/compare_operational_readiness/attempts/a01/artifacts/readiness_comparison.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    # Acceptance Criteria fields
    assert "observability" in data
    assert "security" in data
    assert "deployment_options" in data
    
    # Analytical Depth Floor requirements
    # 1. Failure scenario per approach
    assert "failure_scenario" in data["security"]["LangGraph"]
    assert "failure_scenario" in data["security"]["MAF"]
    
    # 2. Production use case per approach
    assert "production_use_case" in data["deployment_options"]["LangGraph"]
    assert "production_use_case" in data["deployment_options"]["MAF"]
    
    # 3. Complexity/Cost analysis
    assert "analytical_depth" in data
    assert "computational_complexity" in data["analytical_depth"]
    assert "cost_implications" in data["analytical_depth"]

def test_readiness_comparison_content():
    path = "steps/compare_operational_readiness/attempts/a01/artifacts/readiness_comparison.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    # Check for OpenTelemetry
    assert "opentelemetry_support" in data["observability"]["LangGraph"]
    assert "opentelemetry_support" in data["observability"]["MAF"]
    
    # Check for specific deployment patterns
    assert "LangGraph Cloud" in str(data["deployment_options"]["LangGraph"]["patterns"])
    assert "Azure" in str(data["deployment_options"]["MAF"]["patterns"])
