import json
import os

def generate_comparison():
    comparison_data = {
        "observability": {
            "LangGraph": {
                "primary_tool": "LangSmith",
                "opentelemetry_support": "High (via standard Python OTel SDK)",
                "features": ["Trace visualization", "Feedback loops", "Unit testing for chains", "Time-travel debugging"],
                "determinism_classification": "Stochastic (LLM-based) with deterministic control flow (StateGraph)",
                "observability_cost_implication": "LangSmith usage-based pricing; high volume can be costly."
            },
            "MAF": {
                "primary_tool": "Azure AI Foundry / Azure Monitor",
                "opentelemetry_support": "Native (First-class citizen in SDK)",
                "features": ["Azure Application Insights integration", "Distributed tracing across Azure services", "Log Analytics"],
                "determinism_classification": "Hybrid (Workflows provide determinism; Agents provide stochasticity)",
                "observability_cost_implication": "Azure Monitor pricing (ingestion-based); integrated with enterprise Azure billing."
            }
        },
        "security": {
            "LangGraph": {
                "sandboxing": "Managed isolation in LangGraph Cloud; User-defined in self-hosted (e.g., Docker/gVisor)",
                "authentication": "API Key based (LangSmith), OAuth2 for custom deployments",
                "compliance": "SOC2 (LangChain Inc)",
                "failure_scenario": "Sandbox escape in self-hosted environments if not properly configured with container isolation."
            },
            "MAF": {
                "sandboxing": "Azure Container Instances / Azure Functions isolation; VNET support",
                "authentication": "Azure RBAC, Managed Identities, Entra ID",
                "compliance": "Azure Global Compliance (HIPAA, FedRAMP, GDPR, etc.)",
                "failure_scenario": "Misconfiguration of Azure RBAC leading to over-privileged Managed Identities accessing sensitive OneLake data."
            }
        },
        "deployment_options": {
            "LangGraph": {
                "patterns": ["LangGraph Cloud (Managed)", "Self-hosted (Docker/FastAPI)", "Local (Python)"],
                "production_readiness": "High for LangGraph Cloud; Medium-High for self-hosted (requires DevOps effort)",
                "production_use_case": "Customer support agents with complex state transitions and human-in-the-loop requirements."
            },
            "MAF": {
                "patterns": ["Azure AI Foundry", "Azure Functions", "AKS (Azure Kubernetes Service)", "Azure Container Apps"],
                "production_readiness": "Enterprise-grade; deep integration with Azure DevOps/GitHub Actions",
                "production_use_case": "Enterprise-scale data reasoning over OneLake using Fabric data agents and MCP tools."
            }
        },
        "analytical_depth": {
            "computational_complexity": {
                "LangGraph": "O(N * M) where N is nodes and M is average transitions; state management adds overhead.",
                "MAF": "O(N) for workflow-based steps; agentic steps vary by LLM calls and tool usage."
            },
            "cost_implications": {
                "LangGraph": "Lower entry cost (open source); higher operational cost for LangSmith and Cloud managed service.",
                "MAF": "Higher entry complexity (Azure setup); lower marginal cost if already on Azure ecosystem."
            }
        }
    }

    output_path = "steps/compare_operational_readiness/attempts/a01/artifacts/readiness_comparison.json"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(comparison_data, f, indent=2)

if __name__ == "__main__":
    generate_comparison()
