import json
import os

def test_crewai_specs_exists():
    path = "steps/extract_crewai_specs/attempts/a01/artifacts/crewai_specs.json"
    assert os.path.exists(path), f"Artifact {path} does not exist"

def test_crewai_specs_fields():
    path = "steps/extract_crewai_specs/attempts/a01/artifacts/crewai_specs.json"
    with open(path, "r") as f:
        specs = json.load(f)
    
    # Required by acceptance criteria
    assert "orchestration_model" in specs
    assert "agent_roles" in specs
    assert "process_types" in specs
    
    # Required by analytical depth floor
    assert "systems_analysis" in specs
    analysis = specs["systems_analysis"]
    assert "computational_complexity" in analysis
    assert "determinism_spectrum" in analysis
    assert "observability_governance" in analysis
    
    # Check for failure scenarios and use cases in process types
    for proc in ["sequential", "hierarchical"]:
        assert "failure_scenario" in specs["process_types"][proc]
        assert "production_use_case" in specs["process_types"][proc]

if __name__ == "__main__":
    # This allows running the test directly if needed
    try:
        test_crewai_specs_exists()
        test_crewai_specs_fields()
        print("All tests passed!")
    except Exception as e:
        print(f"Tests failed: {e}")
        exit(1)
