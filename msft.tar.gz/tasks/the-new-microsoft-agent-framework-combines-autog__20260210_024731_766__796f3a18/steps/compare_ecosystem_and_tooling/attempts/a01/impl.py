import json
import os

def generate_comparison():
    comparison_data = {
        "frameworks": {
            "LangGraph": {
                "mcp_support": "Full (via LangChain MCP integration)",
                "tool_calling": "Native LangChain tool interfaces, robust schema validation",
                "architectural_matrix": {
                    "planning_topology": "Cyclic Directed Acyclic Graph (DAG) / State Machine",
                    "control_model": "Explicit State Management / Orchestrator",
                    "computational_complexity": "O(N * T) where N=steps, T=tool calls per step",
                    "failure_modes": "Infinite loops in cyclic paths, state corruption in complex transitions",
                    "determinism_spectrum": "High (State-driven transitions)",
                    "observability_governance": "LangSmith (Deep tracing), LangGraph Studio (Visual debugging)",
                    "enterprise_readiness": "High (Persistence, human-in-the-loop, checkpointing)",
                    "composition_patterns": "Nested graphs, sub-graphs as nodes"
                },
                "cost_complexity_analysis": {
                    "token_growth": "Linear with steps, but can be exponential if loops are unconstrained",
                    "branching_behavior": "Explicit branching via conditional edges",
                    "latency_amplification": "Low overhead per step, but sequential steps accumulate latency",
                    "tool_overhead": "Standard JSON-RPC serialization",
                    "memory_scaling": "State is persisted; memory grows with state size across steps",
                    "formal_notation": "C = \\sum_{i=1}^{N} (T_{inference, i} + \\sum_{j=1}^{K_i} T_{tool, j})"
                },
                "enterprise_deployment": {
                    "cost_predictability": "Moderate (depends on loop termination logic)",
                    "reliability_constraints": "Requires robust edge conditions to prevent cycles",
                    "security_isolation": "Standard Python environment isolation",
                    "explainability_auditability": "High (Full state history and path tracing)"
                },
                "failure_scenario": "A support agent enters an infinite loop between 'clarify' and 'search' nodes because the search result never satisfies the clarification requirement.",
                "production_use_case": "Multi-step customer support workflow with human-in-the-loop approval for sensitive actions."
            },
            "CrewAI": {
                "mcp_support": "Partial (via LangChain tool wrappers, moving to native)",
                "tool_calling": "Role-based tool assignment, task-driven execution",
                "architectural_matrix": {
                    "planning_topology": "Sequential, Hierarchical, or Consensual",
                    "control_model": "Manager Agent / Orchestrator-led",
                    "computational_complexity": "O(A * T) where A=Agents, T=Tasks",
                    "failure_modes": "Agent role confusion, 'hallucinated' delegation, redundant task execution",
                    "determinism_spectrum": "Medium (Orchestrator-dependent)",
                    "observability_governance": "AgentOps integration, built-in logging",
                    "enterprise_readiness": "Medium (Good for process automation, less for low-latency)",
                    "composition_patterns": "Crews of agents, hierarchical delegation"
                },
                "cost_complexity_analysis": {
                    "token_growth": "Linear with tasks; overhead from inter-agent communication",
                    "branching_behavior": "Hierarchical delegation creates a tree-like execution path",
                    "latency_amplification": "High (Inter-agent 'thought' process and handoffs)",
                    "tool_overhead": "Context injection into agent prompts",
                    "memory_scaling": "Short-term and long-term memory per agent",
                    "formal_notation": "C = \\sum_{a \\in A} \\sum_{t \\in T_a} (T_{reasoning} + T_{action})"
                },
                "enterprise_deployment": {
                    "cost_predictability": "Low (Agents may take multiple turns to complete a task)",
                    "reliability_constraints": "Sensitive to prompt engineering for roles",
                    "security_isolation": "Agent-level tool restrictions",
                    "explainability_auditability": "Moderate (Agent logs show reasoning, but delegation can be opaque)"
                },
                "failure_scenario": "A 'Researcher' agent delegates a task to a 'Writer' agent, but the 'Writer' keeps asking for more info, leading to a 'delegation ping-pong'.",
                "production_use_case": "Content marketing pipelines where specialized agents research, write, and SEO-optimize articles."
            },
            "AutoGen (AG2)": {
                "mcp_support": "Supported (via extensions and MCP-agent wrappers)",
                "tool_calling": "Conversational tool use, heavy focus on code execution",
                "architectural_matrix": {
                    "planning_topology": "Conversational / Multi-agent Group Chat",
                    "control_model": "Peer-to-Peer / Conversation Manager",
                    "computational_complexity": "O(M^2) in fully connected group chats",
                    "failure_modes": "Conversational drift, deadlock in group consensus, infinite chat loops",
                    "determinism_spectrum": "Low (Emergent behavior from dialogue)",
                    "observability_governance": "Log-based tracing, runtime monitoring",
                    "enterprise_readiness": "Medium (Strong for R&D and coding, harder to constrain for production)",
                    "composition_patterns": "Group chats, nested chats"
                },
                "cost_complexity_analysis": {
                    "token_growth": "Quadratic potential in group chats as context history grows for all participants",
                    "branching_behavior": "Dynamic based on speaker selection logic",
                    "latency_amplification": "High (Multiple agents 'listening' and responding)",
                    "tool_overhead": "Code execution sandbox overhead",
                    "memory_scaling": "Context window management is critical as chat history grows",
                    "formal_notation": "C = \\sum_{i=1}^{Turns} (N_{participants} \\times T_{context} + T_{response})"
                },
                "enterprise_deployment": {
                    "cost_predictability": "Low (Conversation length is highly variable)",
                    "reliability_constraints": "Requires strict 'termination' conditions",
                    "security_isolation": "Critical (Docker/Sandbox for code execution)",
                    "explainability_auditability": "Moderate (Chat logs are readable but reasoning is distributed)"
                },
                "failure_scenario": "In a group chat, two agents get stuck in a 'politeness loop' (e.g., 'After you', 'No, after you') without progressing the task.",
                "production_use_case": "Collaborative software engineering where agents write code, run tests, and fix bugs in a loop."
            },
            "PydanticAI": {
                "mcp_support": "Native (Designed for MCP and type-safety)",
                "tool_calling": "Type-safe Pydantic validation, dependency injection",
                "architectural_matrix": {
                    "planning_topology": "Functional / Linear / Nested Dependency",
                    "control_model": "Dependency Injection / Typed Interface",
                    "computational_complexity": "O(D) where D is dependency depth",
                    "failure_modes": "Validation errors on tool outputs, strict schema mismatches",
                    "determinism_spectrum": "High (Type-constrained)",
                    "observability_governance": "Logfire (Native integration), structured logging",
                    "enterprise_readiness": "High (Type safety, FastAPI-like developer experience)",
                    "composition_patterns": "Nested agents, tool-based composition"
                },
                "cost_complexity_analysis": {
                    "token_growth": "Linear with request/response cycles",
                    "branching_behavior": "Deterministic based on code logic and tool results",
                    "latency_amplification": "Low (Minimal framework overhead)",
                    "tool_overhead": "Pydantic validation overhead (negligible compared to LLM)",
                    "memory_scaling": "Stateless by default, state managed via dependencies",
                    "formal_notation": "C = T_{prompt} + T_{tool\\_validation} + T_{completion}"
                },
                "enterprise_deployment": {
                    "cost_predictability": "High (Direct mapping of calls to costs)",
                    "reliability_constraints": "Requires accurate Pydantic models for all tools",
                    "security_isolation": "Standard Python/FastAPI security patterns",
                    "explainability_auditability": "High (Structured logs and typed inputs/outputs)"
                },
                "failure_scenario": "An agent fails to process a tool result because the external API returned a field that didn't match the strict Pydantic model definition.",
                "production_use_case": "Data extraction and structured API interaction where reliability and type safety are paramount."
            }
        }
    }
    
    # Ensure directory exists
    os.makedirs('steps/compare_ecosystem_and_tooling/attempts/a01/artifacts', exist_ok=True)
    
    with open('steps/compare_ecosystem_and_tooling/attempts/a01/artifacts/ecosystem_comparison.json', 'w') as f:
        json.dump(comparison_data, f, indent=2)

if __name__ == "__main__":
    generate_comparison()
