import json
import os
import pytest

def test_ecosystem_comparison_exists():
    path = 'steps/compare_ecosystem_and_tooling/attempts/a01/artifacts/ecosystem_comparison.json'
    assert os.path.exists(path), "ecosystem_comparison.json does not exist"

def test_ecosystem_comparison_content():
    path = 'steps/compare_ecosystem_and_tooling/attempts/a01/artifacts/ecosystem_comparison.json'
    with open(path, 'r') as f:
        data = json.load(f)
    
    frameworks = ["LangGraph", "CrewAI", "AutoGen (AG2)", "PydanticAI"]
    for fw in frameworks:
        assert fw in data["frameworks"], f"Missing {fw} in comparison"
        fw_data = data["frameworks"][fw]
        
        # Check MCP support
        assert "mcp_support" in fw_data
        
        # Check Architectural Matrix
        matrix = fw_data["architectural_matrix"]
        required_matrix_keys = [
            "planning_topology", "control_model", "computational_complexity", 
            "failure_modes", "determinism_spectrum", "observability_governance", 
            "enterprise_readiness", "composition_patterns"
        ]
        for key in required_matrix_keys:
            assert key in matrix, f"Missing {key} in architectural_matrix for {fw}"
            
        # Check Complexity and Cost Analysis
        cost_analysis = fw_data["cost_complexity_analysis"]
        required_cost_keys = [
            "token_growth", "branching_behavior", "latency_amplification", 
            "tool_overhead", "memory_scaling", "formal_notation"
        ]
        for key in required_cost_keys:
            assert key in cost_analysis, f"Missing {key} in cost_complexity_analysis for {fw}"
            
        # Check Enterprise Deployment Guidance
        deployment = fw_data["enterprise_deployment"]
        required_deployment_keys = [
            "cost_predictability", "reliability_constraints", 
            "security_isolation", "explainability_auditability"
        ]
        for key in required_deployment_keys:
            assert key in deployment, f"Missing {key} in enterprise_deployment for {fw}"
            
        # Check Failure Scenario and Production Use Case
        assert "failure_scenario" in fw_data
        assert "production_use_case" in fw_data

if __name__ == "__main__":
    pytest.main([__file__])
