import json
import os

def test_maf_specs_exists():
    path = "steps/extract_maf_specs/attempts/a01/artifacts/maf_specs.json"
    assert os.path.exists(path), f"{path} does not exist"

def test_maf_specs_fields():
    path = "steps/extract_maf_specs/attempts/a01/artifacts/maf_specs.json"
    with open(path, "r") as f:
        specs = json.load(f)
    
    required_fields = ["architecture_type", "primary_abstractions", "language_support"]
    for field in required_fields:
        assert field in specs, f"Missing required field: {field}"
        assert specs[field], f"Field {field} is empty"

def test_maf_specs_content():
    path = "steps/extract_maf_specs/attempts/a01/artifacts/maf_specs.json"
    with open(path, "r") as f:
        specs = json.load(f)
    
    # Check for Actor model
    abstractions = str(specs["primary_abstractions"]).lower()
    assert "actor" in abstractions, "Primary abstractions should mention Actor model"
    
    # Check for core components
    assert "AgentChat" in specs["core_components"], "Missing AgentChat component"
    assert "Core" in specs["core_components"], "Missing Core component"
    
    # Check language support
    languages = [lang.lower() for lang in specs["language_support"]]
    assert any("python" in lang for lang in languages), "Should support Python"
    assert any(".net" in lang or "c#" in lang for lang in languages), "Should support .NET/C#"

def test_analytical_depth():
    path = "steps/extract_maf_specs/attempts/a01/artifacts/maf_specs.json"
    with open(path, "r") as f:
        specs = json.load(f)
    
    # Assert systems-level dimensions
    assert "architecture_type" in specs
    assert "computational_complexity_notes" in specs
    assert "determinism_classification" in specs
