import os
import json
import pytest

ARTIFACT_PATH = "steps/compare_architectural_patterns/attempts/a01/artifacts/architecture_comparison.json"

def test_artifact_exists():
    assert os.path.exists(ARTIFACT_PATH), f"Artifact {ARTIFACT_PATH} does not exist"

def test_framework_mapping():
    with open(ARTIFACT_PATH, 'r') as f:
        data = json.load(f)
    
    frameworks = ["Microsoft AutoGen", "LangGraph", "CrewAI"]
    for fw in frameworks:
        assert fw in data["frameworks"], f"Framework {fw} missing from comparison"
        assert "paradigm" in data["frameworks"][fw], f"Paradigm missing for {fw}"
        assert data["frameworks"][fw]["paradigm"] is not None

def test_analytical_depth():
    with open(ARTIFACT_PATH, 'r') as f:
        data = json.load(f)
    
    required_keys = [
        "paradigm",
        "control_model",
        "computational_complexity",
        "cost_latency_implications",
        "determinism_spectrum",
        "failure_modes",
        "production_readiness",
        "composition_patterns"
    ]
    
    for fw, details in data["frameworks"].items():
        for key in required_keys:
            assert key in details, f"Analytical dimension '{key}' missing for {fw}"
            if key == "failure_modes":
                assert isinstance(details[key], list) and len(details[key]) > 0, f"Failure modes must be a non-empty list for {fw}"
            else:
                assert isinstance(details[key], str) and len(details[key]) > 0, f"Dimension '{key}' must be a non-empty string for {fw}"

def test_topology_classification():
    with open(ARTIFACT_PATH, 'r') as f:
        data = json.load(f)
    
    for fw, details in data["frameworks"].items():
        assert "topology" in details, f"Topology classification missing for {fw}"
