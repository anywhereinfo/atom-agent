import os
import json

def generate_comparison():
    comparison_data = {
        "frameworks": {
            "Microsoft AutoGen": {
                "paradigm": "Actor Model / Conversational",
                "control_model": "Decentralized Peer-to-Peer",
                "topology": "Mesh / Fully Connected",
                "computational_complexity": "O(N^2) for N agents in a broadcast group",
                "cost_latency_implications": "High latency due to multi-turn reasoning; variable cost based on conversation length.",
                "determinism_spectrum": "Low - Emergent behavior from agent interactions.",
                "failure_modes": [
                    "Infinite conversational loops",
                    "Context window overflow in long dialogues",
                    "Agent role-play drift"
                ],
                "production_readiness": "High for R&D; moderate for production due to non-deterministic paths.",
                "composition_patterns": "Agent-to-Agent handoffs, GroupChatManager."
            },
            "LangGraph": {
                "paradigm": "State Graph / Cyclic DAG",
                "control_model": "Explicit State Machine",
                "topology": "Directed Graph (Cyclic or Acyclic)",
                "computational_complexity": "O(V + E) where V is nodes and E is transitions",
                "cost_latency_implications": "Predictable latency per node; cost scales linearly with graph traversal.",
                "determinism_spectrum": "High - Transitions are explicitly defined by logic or LLM routing.",
                "failure_modes": [
                    "Infinite cycles if termination condition is weak",
                    "State schema mismatches between nodes",
                    "Graph deadlock"
                ],
                "production_readiness": "Very High - Designed for controllable, observable workflows.",
                "composition_patterns": "Conditional edges, Subgraphs, State persistence."
            },
            "CrewAI": {
                "paradigm": "Role-based / Hierarchical",
                "control_model": "Manager-led or Sequential Process",
                "topology": "Tree / Linear Sequence",
                "computational_complexity": "O(N) for sequential; O(N) for manager-led delegation",
                "cost_latency_implications": "Moderate; overhead from manager agent coordination.",
                "determinism_spectrum": "Medium - Structured by tasks but agent execution is flexible.",
                "failure_modes": [
                    "Manager agent bottleneck",
                    "Task dependency failures",
                    "Role overlap/confusion"
                ],
                "production_readiness": "High for business process automation and structured tasks.",
                "composition_patterns": "Task-Role mapping, Sequential/Hierarchical processes."
            }
        },
        "comparative_summary": {
            "best_for_exploration": "Microsoft AutoGen",
            "best_for_reliability": "LangGraph",
            "best_for_business_processes": "CrewAI"
        }
    }

    # Ensure directory exists
    artifact_path = "steps/compare_architectural_patterns/attempts/a01/artifacts/architecture_comparison.json"
    os.makedirs(os.path.dirname(artifact_path), exist_ok=True)

    with open(artifact_path, 'w') as f:
        json.dump(comparison_data, f, indent=4)

if __name__ == "__main__":
    generate_comparison()
