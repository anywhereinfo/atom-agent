import json
import os
import pytest

def test_orchestration_comparison_exists():
    path = "steps/compare_orchestration_mechanisms/attempts/a01/artifacts/orchestration_comparison.json"
    assert os.path.exists(path), f"Artifact {path} does not exist"

def test_orchestration_comparison_content():
    path = "steps/compare_orchestration_mechanisms/attempts/a01/artifacts/orchestration_comparison.json"
    with open(path, "r") as f:
        data = json.load(f)
    
    frameworks = ["MAF", "LangGraph", "CrewAI"]
    required_keys = ["communication_style", "loop_handling", "termination_logic"]
    analytical_keys = [
        "planning_topology", 
        "control_model", 
        "computational_complexity", 
        "failure_modes", 
        "determinism",
        "enterprise_readiness"
    ]
    
    for fw in frameworks:
        assert fw in data["frameworks"], f"Missing framework: {fw}"
        for key in required_keys:
            assert key in data["frameworks"][fw], f"Missing key '{key}' in {fw}"
            assert isinstance(data["frameworks"][fw][key], str)
            assert len(data["frameworks"][fw][key]) > 0
            
        for key in analytical_keys:
            assert key in data["frameworks"][fw], f"Missing analytical key '{key}' in {fw}"
            
    # Check for failure scenarios (at least one per approach)
    for fw in frameworks:
        assert len(data["frameworks"][fw]["failure_modes"]) >= 1, f"No failure modes for {fw}"

def test_analytical_depth():
    path = "steps/compare_orchestration_mechanisms/attempts/a01/artifacts/orchestration_comparison.json"
    with open(path, "r") as f:
        data = json.load(f)
        
    # Check for complexity notation in at least one framework
    found_complexity_notation = False
    for fw in data["frameworks"]:
        if "O(" in data["frameworks"][fw]["computational_complexity"]:
            found_complexity_notation = True
            break
    assert found_complexity_notation, "No formal complexity notation (O(n)) found in comparison"

if __name__ == "__main__":
    pytest.main([__file__])
