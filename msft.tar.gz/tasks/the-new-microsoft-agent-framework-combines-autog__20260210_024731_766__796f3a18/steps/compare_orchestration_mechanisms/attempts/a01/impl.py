import json
import os

def generate_comparison():
    comparison = {
        "frameworks": {
            "MAF": {
                "communication_style": "Message-based interaction (Conversational)",
                "loop_handling": "Conversational loops; agents exchange messages until a stop condition is met.",
                "termination_logic": "Keyword-based (e.g., 'TERMINATE'), max rounds, or custom transition functions.",
                "planning_topology": "Mesh / Conversational",
                "control_model": "Decentralized (Peer-to-peer) or Centralized (Group Chat Manager)",
                "computational_complexity": "O(N^2) for full mesh, O(N) per round for group chat. High token cost due to chat history.",
                "determinism": "Low; highly dependent on LLM response for flow control.",
                "failure_modes": ["Conversational drift", "Infinite 'thank you' loops", "Termination keyword missed"],
                "observability": "Message logs, conversation history.",
                "enterprise_readiness": "High for R&D and complex reasoning; requires strict guardrails for production.",
                "composition_patterns": "Peer-to-peer, Group Chat, Nested Chats"
            },
            "LangGraph": {
                "communication_style": "State transitions (Shared State Object)",
                "loop_handling": "Cyclic graphs; explicit edges define loops back to previous nodes.",
                "termination_logic": "Explicit 'END' node or conditional edge logic.",
                "planning_topology": "Directed Cyclic Graph (DCG)",
                "control_model": "Centralized state management with decentralized node execution.",
                "computational_complexity": "O(V + E) for graph traversal. Latency depends on node execution time.",
                "determinism": "High; flow is explicitly defined by graph edges, though routing can be stochastic.",
                "failure_modes": ["State corruption", "Infinite loops (if no max_iterations)", "Deadlocks"],
                "observability": "Graph visualization, state snapshots, checkpointing.",
                "enterprise_readiness": "Very High; built-in persistence, human-in-the-loop, and time-travel debugging.",
                "composition_patterns": "Sub-graphs, Map-Reduce, Multi-agent graphs"
            },
            "CrewAI": {
                "communication_style": "Task handoffs (Role-based)",
                "loop_handling": "Sequential or Hierarchical processes; task-driven iteration.",
                "termination_logic": "Completion of all tasks or Manager agent decision.",
                "planning_topology": "Sequential / Hierarchical",
                "control_model": "Semi-centralized (Manager agent or Process controller)",
                "computational_complexity": "Linear O(T) where T is number of tasks. Manager overhead adds constant factor.",
                "determinism": "Moderate; task structure provides strong guardrails.",
                "failure_modes": ["Task handoff failures", "Manager agent hallucination", "Context window overflow"],
                "observability": "Task status, agent logs, process telemetry.",
                "enterprise_readiness": "High for business process automation and role-based workflows.",
                "composition_patterns": "Sequential, Hierarchical, Joint-Task"
            }
        },
        "summary_analysis": {
            "best_for_determinism": "LangGraph",
            "best_for_flexibility": "MAF",
            "best_for_structured_tasks": "CrewAI"
        }
    }

    # Ensure the directory exists
    os.makedirs("steps/compare_orchestration_mechanisms/attempts/a01/artifacts", exist_ok=True)
    
    output_path = "steps/compare_orchestration_mechanisms/attempts/a01/artifacts/orchestration_comparison.json"
    with open(output_path, "w") as f:
        json.dump(comparison, f, indent=2)
    
    print(f"Artifact created at {output_path}")

if __name__ == "__main__":
    generate_comparison()
